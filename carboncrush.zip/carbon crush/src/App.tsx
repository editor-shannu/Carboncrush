import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth } from './firebase/config';
import { initializeUserProfile, getUserProfile, UserProfile } from './firebase/firestore';
import LoginPage from './components/LoginPage';
import HomePage from './components/HomePage';
import ChallengesPage from './components/ChallengesPage';
import LeaderboardPage from './components/LeaderboardPage';
import CommunityPage from './components/CommunityPage';
import ProfilePage from './components/ProfilePage';
import WeeklyLeaderboardAnnouncement from './components/WeeklyLeaderboardAnnouncement';

function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [currentPage, setCurrentPage] = useState('home');
  const [showWeeklyAnnouncement, setShowWeeklyAnnouncement] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Toast notification system
  const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Check if it's time to show weekly announcement (Sunday at midnight)
  useEffect(() => {
    const checkWeeklyAnnouncement = () => {
      const now = new Date();
      const lastAnnouncement = localStorage.getItem('lastWeeklyAnnouncement');
      const currentWeek = `${now.getFullYear()}-W${Math.ceil(now.getDate() / 7)}`;
      
      // Show announcement if it's a new week and user is logged in
      if (user && lastAnnouncement !== currentWeek) {
        // Simulate weekly announcement trigger (for demo, show after 3 seconds)
        const timer = setTimeout(() => {
          setShowWeeklyAnnouncement(true);
          localStorage.setItem('lastWeeklyAnnouncement', currentWeek);
        }, 3000);
        
        return () => clearTimeout(timer);
      }
    };

    if (user) {
      checkWeeklyAnnouncement();
    }
  }, [user]);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        const handleUser = async () => {
          try {
            // Initialize user profile and give 100 points for new users
            await initializeUserProfile(user);
            
            // Fetch user profile
            const profile = await getUserProfile(user.uid);
            setUserProfile(profile);
            
            setUser(user);
            setLoading(false);
          } catch (error) {
            console.error('Error initializing user:', error);
            setUser(user);
            setLoading(false);
          }
        };
        
        handleUser();
        setUser(user);
        setLoading(false);
      } else {
        setUser(null);
        setUserProfile(null);
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const handleLogin = () => {
    // User state will be updated by onAuthStateChanged
    setLoading(false);
  };

  const handleNavigate = (page: string) => {
    setCurrentPage(page);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-900 via-emerald-800 to-teal-900 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mb-4 mx-auto animate-pulse">
            <div className="w-8 h-8 bg-green-600 rounded-full"></div>
          </div>
          <h2 className="text-white text-xl font-bold">Loading Carbon Crush...</h2>
        </div>
      </div>
    );
  }

  if (!user) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'challenges':
        return <ChallengesPage onNavigate={handleNavigate} user={user} userProfile={userProfile} onUpdateProfile={setUserProfile} showToast={showToast} />;
      case 'leaderboard':
        return <LeaderboardPage onNavigate={handleNavigate} user={user} showToast={showToast} />;
      case 'community':
        return <CommunityPage onNavigate={handleNavigate} user={user} showToast={showToast} />;
      case 'profile':
        return <ProfilePage onNavigate={handleNavigate} user={user} userProfile={userProfile} showToast={showToast} />;
      default:
        return <HomePage onNavigate={handleNavigate} user={user} userProfile={userProfile} showToast={showToast} />;
    }
  };

  return (
    <div className="App">
      {renderCurrentPage()}
      
      {/* Weekly Leaderboard Announcement */}
      {showWeeklyAnnouncement && (
        <WeeklyLeaderboardAnnouncement 
          onClose={() => setShowWeeklyAnnouncement(false)} 
        />
      )}
      
      {/* Toast Notification */}
      {toast && (
        <div className={`fixed top-4 right-4 z-50 px-4 py-2 rounded-lg shadow-lg text-white ${
          toast.type === 'success' ? 'bg-green-500' : 
          toast.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
        }`}>
          {toast.message}
        </div>
      )}
    </div>
  );
}

export default App;