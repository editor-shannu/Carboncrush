import { createClient } from '@supabase/supabase-js';
import { auth } from '../firebase/config';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface Post {
  id: string;
  author: string;
  content: string;
  timestamp: string;
  likes: number;
  user_id: string;
  image_url?: string;
  created_at: string;
}

// Post creation function
export async function createPost(content: string, author: string, firebaseUserId: string, imageUrl?: string) {
  if (!content.trim()) {
    throw new Error('Post content cannot be empty');
  }

  console.log('Creating post with Firebase UID:', firebaseUserId); // Debug log

  // Get current Firebase user to ensure we're authenticated
  const currentUser = auth.currentUser;
  if (!currentUser) {
    throw new Error('User must be logged in to create posts');
  }

  // Authenticate with Supabase using Firebase token
  const token = await currentUser.getIdToken();
  await supabase.auth.setSession({
    access_token: token,
    refresh_token: token
  });

  const { data, error } = await supabase
    .from('posts')
    .insert([
      {
        content: content.trim(),
        author,
        user_id: firebaseUserId, // Firebase UID as text
        image_url: imageUrl
      }
    ])
    .select()
    .single();

  if (error) {
    console.error('Error creating post:', error);
    throw new Error(`Failed to create post: ${error.message}`);
  }

  console.log('Post created successfully:', data); // Debug log
  return data;
}

// Fetch posts function
export async function fetchPosts(): Promise<Post[]> {
  const { data, error } = await supabase
    .from('posts')
    .select('*')
    .order('timestamp', { ascending: false });

  if (error) {
    console.error('Error fetching posts:', error);
    throw new Error(`Failed to fetch posts: ${error.message}`);
  }

  return data || [];
}

// Real-time subscription for posts
export function subscribeToPosts(callback: (posts: Post[]) => void) {
  // Initial fetch
  fetchPosts().then(callback).catch(console.error);

  // Set up real-time subscription
  const subscription = supabase
    .channel('posts_changes')
    .on(
      'postgres_changes',
      {
        event: '*',
        schema: 'public',
        table: 'posts'
      },
      () => {
        // Refetch posts when any change occurs
        fetchPosts().then(callback).catch(console.error);
      }
    )
    .subscribe();

  // Return unsubscribe function
  return () => {
    subscription.unsubscribe();
  };
}

// Like post function
export async function likePost(postId: string) {
  const { error } = await supabase
    .from('posts')
    .update({ likes: supabase.sql`likes + 1` })
    .eq('id', postId);

  if (error) {
    console.error('Error liking post:', error);
    throw new Error(`Failed to like post: ${error.message}`);
  }
}

// Format time ago helper
export function formatTimeAgo(timestamp: string): string {
  const now = new Date();
  const postTime = new Date(timestamp);
  const diffMs = now.getTime() - postTime.getTime();
  
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  
  if (diffMinutes < 1) return 'Just now';
  if (diffMinutes < 60) return `${diffMinutes}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return postTime.toLocaleDateString();
}