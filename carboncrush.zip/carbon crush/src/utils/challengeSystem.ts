// Challenge System Utilities
export interface Challenge {
  id: number;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  points: number;
  timeLeft: string;
  color: string;
  icon: string;
  category: string;
}

export interface ChallengeProof {
  challengeId: number;
  userId: string;
  userName: string;
  userAvatar: string;
  proof: string; // base64 image or description
  description: string;
  completedAt: number;
  points: number;
}

export interface WeeklyScore {
  userId: string;
  userName: string;
  userAvatar: string;
  totalPoints: number;
  challengesCompleted: number;
  week: string;
}

// Challenge pools by difficulty
export const challengePools = {
  Easy: [
    {
      title: "Use a reusable water bottle today",
      description: "Avoid single-use plastic bottles",
      points: 50,
      icon: "💧",
      category: "waste-reduction"
    },
    {
      title: "Turn off lights when leaving a room",
      description: "Save energy throughout the day",
      points: 40,
      icon: "💡",
      category: "energy-saving"
    },
    {
      title: "Use both sides of paper",
      description: "Reduce paper waste",
      points: 30,
      icon: "📄",
      category: "waste-reduction"
    },
    {
      title: "Unplug electronics when not in use",
      description: "Prevent phantom energy consumption",
      points: 45,
      icon: "🔌",
      category: "energy-saving"
    },
    {
      title: "Take a shorter shower",
      description: "Reduce water consumption by 2 minutes",
      points: 35,
      icon: "🚿",
      category: "water-conservation"
    }
  ],
  Medium: [
    {
      title: "Take public transport or bike",
      description: "Reduce your carbon footprint",
      points: 100,
      icon: "🚌",
      category: "transportation"
    },
    {
      title: "Start composting organic waste",
      description: "Turn food scraps into fertilizer",
      points: 120,
      icon: "🗂️",
      category: "waste-reduction"
    },
    {
      title: "Use eco-friendly cleaning products",
      description: "Switch to natural alternatives",
      points: 90,
      icon: "🧽",
      category: "lifestyle"
    },
    {
      title: "Meal prep to reduce food waste",
      description: "Plan and prepare meals for the week",
      points: 110,
      icon: "🥗",
      category: "food-waste"
    },
    {
      title: "Switch to LED bulbs",
      description: "Replace 3 incandescent bulbs with LEDs",
      points: 130,
      icon: "💡",
      category: "energy-saving"
    }
  ],
  Hard: [
    {
      title: "Plant a tree or start a garden",
      description: "Contribute to carbon absorption",
      points: 200,
      icon: "🌱",
      category: "environmental-action"
    },
    {
      title: "Go car-free for a week",
      description: "Use only sustainable transportation",
      points: 250,
      icon: "🚲",
      category: "transportation"
    },
    {
      title: "Install solar panels or renewable energy",
      description: "Switch to clean energy source",
      points: 300,
      icon: "☀️",
      category: "renewable-energy"
    },
    {
      title: "Organize a community cleanup",
      description: "Lead an environmental cleanup event",
      points: 220,
      icon: "🧹",
      category: "community-action"
    },
    {
      title: "Go plastic-free for a month",
      description: "Eliminate single-use plastics completely",
      points: 280,
      icon: "♻️",
      category: "waste-reduction"
    }
  ]
};

export const generateNewChallenge = (difficulty: Challenge['difficulty'], completedChallenges: number[]): Partial<Challenge> => {
  const pool = challengePools[difficulty];
  const availableChallenges = pool.filter((_, index) => !completedChallenges.includes(index));
  
  if (availableChallenges.length === 0) {
    // If all challenges in difficulty are completed, pick a random one
    const randomChallenge = pool[Math.floor(Math.random() * pool.length)];
    return randomChallenge;
  }
  
  const randomChallenge = availableChallenges[Math.floor(Math.random() * availableChallenges.length)];
  return randomChallenge;
};

export const getColorForDifficulty = (difficulty: Challenge['difficulty']): string => {
  switch (difficulty) {
    case 'Easy': return 'from-green-400 to-emerald-500';
    case 'Medium': return 'from-yellow-400 to-orange-500';
    case 'Hard': return 'from-red-400 to-pink-500';
    default: return 'from-gray-400 to-gray-500';
  }
};

export const calculateTimeLeft = (): string => {
  const now = new Date();
  const endOfWeek = new Date(now);
  endOfWeek.setDate(now.getDate() + (7 - now.getDay()));
  endOfWeek.setHours(23, 59, 59, 999);
  
  const timeDiff = endOfWeek.getTime() - now.getTime();
  const daysLeft = Math.ceil(timeDiff / (1000 * 60 * 60 * 24));
  
  return `${daysLeft} day${daysLeft !== 1 ? 's' : ''}`;
};

export const getCurrentWeek = (): string => {
  const now = new Date();
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  
  const endOfWeek = new Date(startOfWeek);
  endOfWeek.setDate(startOfWeek.getDate() + 6);
  
  return `${startOfWeek.toLocaleDateString()} - ${endOfWeek.toLocaleDateString()}`;
};

// Local storage utilities
export const saveUserScore = (userId: string, points: number) => {
  const currentWeek = getCurrentWeek();
  const scores = JSON.parse(localStorage.getItem('weeklyScores') || '{}');
  
  if (!scores[currentWeek]) {
    scores[currentWeek] = {};
  }
  
  if (!scores[currentWeek][userId]) {
    scores[currentWeek][userId] = {
      totalPoints: 0,
      challengesCompleted: 0
    };
  }
  
  scores[currentWeek][userId].totalPoints += points;
  scores[currentWeek][userId].challengesCompleted += 1;
  
  localStorage.setItem('weeklyScores', JSON.stringify(scores));
};

export const getWeeklyLeaderboard = (week?: string): WeeklyScore[] => {
  const targetWeek = week || getCurrentWeek();
  const scores = JSON.parse(localStorage.getItem('weeklyScores') || '{}');
  const users = JSON.parse(localStorage.getItem('users') || '{}');
  
  if (!scores[targetWeek]) return [];
  
  return Object.entries(scores[targetWeek])
    .map(([userId, data]: [string, any]) => ({
      userId,
      userName: users[userId]?.name || 'Anonymous User',
      userAvatar: users[userId]?.avatar || '🌱',
      totalPoints: data.totalPoints,
      challengesCompleted: data.challengesCompleted,
      week: targetWeek
    }))
    .sort((a, b) => b.totalPoints - a.totalPoints);
};

export const saveUserInfo = (userId: string, name: string, avatar: string) => {
  const users = JSON.parse(localStorage.getItem('users') || '{}');
  users[userId] = { name, avatar };
  localStorage.setItem('users', JSON.stringify(users));
};

export const saveCommunityPost = (post: any) => {
  const posts = JSON.parse(localStorage.getItem('communityPosts') || '[]');
  posts.unshift(post);
  localStorage.setItem('communityPosts', JSON.stringify(posts));
};

export const getCommunityPosts = () => {
  return JSON.parse(localStorage.getItem('communityPosts') || '[]');
};