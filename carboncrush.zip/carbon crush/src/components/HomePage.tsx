import React from 'react';
import { motion } from 'framer-motion';
import { signOut } from 'firebase/auth';
import { auth } from '../firebase/config';
import { getUserProfile, UserProfile } from '../firebase/firestore';
import CO2Tracker from './CO2Tracker';
import { 
  Home, 
  Calendar, 
  Trophy, 
  Globe, 
  User, 
  Zap, 
  Target, 
  Award,
  TrendingUp,
  Users,
  Leaf,
  LogOut
} from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: string) => void;
  user: any;
  userProfile: UserProfile | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const HomePage: React.FC<HomePageProps> = ({ onNavigate, user, userProfile, showToast }) => {

  const challenges = [
    { id: 1, title: "Use reusable water bottle", difficulty: "Easy", points: 50, color: "bg-green-400" },
    { id: 2, title: "Take public transport", difficulty: "Medium", points: 100, color: "bg-yellow-400" },
    { id: 3, title: "Plant a tree", difficulty: "Hard", points: 200, color: "bg-red-400" }
  ];

  // Use real user data or defaults
  const stats = {
    weeklyPoints: userProfile?.weeklyScore || 0,
    ecoLevel: userProfile?.ecoLevel || 1,
    streak: userProfile?.dayStreak || 0
  };

  const handleSignOut = async () => {
    try {
      await signOut(auth);
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleChallengeStart = (challengeId: number) => {
    // Navigate to challenges page
    onNavigate('challenges');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <motion.div
        className="bg-white shadow-lg rounded-b-3xl p-6 mb-6"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">
              Welcome back, {user?.displayName || user?.email?.split('@')[0] || 'Eco Hero'}! 🌱
            </h1>
            <p className="text-gray-600">Level {stats.ecoLevel} • {stats.streak} day streak</p>
          </div>
          <div className="flex items-center space-x-3">
            <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
              {user?.photoURL ? (
                <img 
                  src={user.photoURL} 
                  alt="Profile" 
                  className="w-14 h-14 rounded-full object-cover"
                />
              ) : (
                <Leaf className="w-8 h-8 text-white" />
              )}
            </div>
            <motion.button
              onClick={handleSignOut}
              className="p-3 bg-red-100 hover:bg-red-200 rounded-full transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              title="Sign Out"
            >
              <LogOut className="w-5 h-5 text-red-600" />
            </motion.button>
          </div>
        </div>
      </motion.div>

      <div className="px-6 pb-24">
        {/* Stats Cards */}
        <motion.div
          className="grid grid-cols-3 gap-4 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="bg-white rounded-2xl p-4 text-center shadow-lg">
            <Zap className="w-8 h-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-800">{stats.weeklyPoints}</div>
            <div className="text-xs text-gray-600">Weekly Points</div>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-lg">
            <Target className="w-8 h-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-800">{stats.ecoLevel}</div>
            <div className="text-xs text-gray-600">Eco Level</div>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-lg">
            <TrendingUp className="w-8 h-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold text-gray-800">{stats.streak}</div>
            <div className="text-xs text-gray-600">Day Streak</div>
          </div>
        </motion.div>

        {/* This Week's Challenges */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <h2 className="text-xl font-bold text-gray-800 mb-4">This Week's Challenges</h2>
          <div className="space-y-3">
            {challenges.map((challenge, index) => (
              <motion.div
                key={challenge.id}
                className="bg-white rounded-2xl p-4 shadow-lg"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-3 h-3 rounded-full ${challenge.color}`} />
                    <div>
                      <h3 className="font-semibold text-gray-800">{challenge.title}</h3>
                      <p className="text-sm text-gray-600">{challenge.difficulty} • {challenge.points} points</p>
                    </div>
                  </div>
                  <motion.button
                    onClick={() => handleChallengeStart(challenge.id)}
                    className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-xl text-sm font-medium"
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                  >
                    Start
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Quick Links */}
        <motion.div
          className="grid grid-cols-2 gap-4 mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <motion.button
            onClick={() => onNavigate('leaderboard')}
            className="bg-gradient-to-br from-yellow-400 to-orange-500 rounded-2xl p-6 text-white shadow-lg"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Trophy className="w-8 h-8 mb-2" />
            <div className="font-semibold">Leaderboard</div>
            <div className="text-sm opacity-90">See your rank</div>
          </motion.button>
          <motion.button
            onClick={() => onNavigate('community')}
            className="bg-gradient-to-br from-blue-400 to-purple-500 rounded-2xl p-6 text-white shadow-lg"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Users className="w-8 h-8 mb-2" />
            <div className="font-semibold">Community</div>
            <div className="text-sm opacity-90">Connect & share</div>
          </motion.button>
        </motion.div>

        {/* CO₂ Tracker */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <CO2Tracker 
            onRideComplete={(rideData) => {
              showToast(`Ride completed! CO₂ tracked: ${rideData.co2Emitted.toFixed(0)}g`, 'success');
            }} 
            showToast={showToast}
          />
        </motion.div>
      </div>

      {/* Bottom Navigation */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-6 py-3">
        <div className="flex justify-around">
          {[
            { icon: Home, label: 'Home', page: 'home', active: true },
            { icon: Calendar, label: 'Challenges', page: 'challenges' },
            { icon: Trophy, label: 'Leaderboard', page: 'leaderboard' },
            { icon: Globe, label: 'Community', page: 'community' },
            { icon: User, label: 'Profile', page: 'profile' }
          ].map((item) => (
            <motion.button
              key={item.page}
              onClick={() => onNavigate(item.page)}
              className={`flex flex-col items-center space-y-1 p-2 rounded-xl ${
                item.active ? 'text-green-600 bg-green-50' : 'text-gray-400'
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <item.icon className="w-6 h-6" />
              <span className="text-xs font-medium">{item.label}</span>
              {item.active && (
                <motion.div
                  className="w-1 h-1 bg-green-600 rounded-full"
                  layoutId="activeTab"
                />
              )}
            </motion.button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HomePage;