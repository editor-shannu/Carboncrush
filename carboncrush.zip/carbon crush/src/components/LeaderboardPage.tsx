import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { getLeaderboard, UserProfile, searchUsers, sendFriendRequest, getUserFriends } from '../firebase/firestore';
import { ArrowLeft, Trophy, Medal, Award, Crown, Users, Globe, MapPin, UserPlus, Search, X } from 'lucide-react';

interface LeaderboardPageProps {
  onNavigate: (page: string) => void;
  user?: any;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const LeaderboardPage: React.FC<LeaderboardPageProps> = ({ onNavigate, user, showToast }) => {
  const [activeTab, setActiveTab] = useState('friends');
  const [leaderboardData, setLeaderboardData] = useState<UserProfile[]>([]);
  const [friendsData, setFriendsData] = useState<UserProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFriendSearch, setShowFriendSearch] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<UserProfile[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  // Real-time leaderboard subscription
  React.useEffect(() => {
    const unsubscribe = getLeaderboard((users) => {
      setLeaderboardData(users);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Load friends data
  React.useEffect(() => {
    if (user && activeTab === 'friends') {
      getUserFriends(user.uid).then(friends => {
        setFriendsData(friends);
      });
    }
  }, [user, activeTab]);

  // Search users with debounce
  React.useEffect(() => {
    if (searchTerm.length >= 2 && user) {
      setIsSearching(true);
      const timeoutId = setTimeout(async () => {
        try {
          const results = await searchUsers(searchTerm, user.uid);
          setSearchResults(results);
        } catch (error) {
          console.error('Search error:', error);
        } finally {
          setIsSearching(false);
        }
      }, 500);
      
      return () => clearTimeout(timeoutId);
    } else {
      setSearchResults([]);
      setIsSearching(false);
    }
  }, [searchTerm, user]);
  const handleAddFriends = () => {
    setShowFriendSearch(true);
  };

  const handleSendFriendRequest = async (friendId: string) => {
    if (!user) return;
    
    try {
      await sendFriendRequest(user.uid, friendId);
      showToast('Friend request sent!', 'success');
      // Remove from search results
      setSearchResults(prev => prev.filter(u => u.uid !== friendId));
    } catch (error) {
      showToast('Failed to send friend request', 'error');
    }
  };

  // Get current data based on active tab
  const getCurrentData = () => {
    if (activeTab === 'friends') {
      return friendsData.length > 0 ? friendsData : leaderboardData.slice(0, 5);
    }
    // For state, country, and global - show real users from Firebase
    // In a real app, you'd filter by location, but for now show all real users
    if (activeTab === 'state' || activeTab === 'country' || activeTab === 'global') {
      return leaderboardData;
    }
    return [];
  };

  const currentData = getCurrentData();

  const tabs = [
    { id: 'friends', label: 'Friends', icon: Users },
    { id: 'state', label: 'State', icon: MapPin },
    { id: 'country', label: 'Country', icon: Globe },
    { id: 'global', label: 'Global', icon: Crown }
  ];

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2: return <Medal className="w-6 h-6 text-gray-400" />;
      case 3: return <Award className="w-6 h-6 text-amber-600" />;
      default: return <span className="w-6 h-6 flex items-center justify-center text-gray-500 font-bold">{rank}</span>;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-100">
      {/* Header */}
      <motion.div
        className="bg-white shadow-lg rounded-b-3xl p-6 mb-6"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center space-x-4">
          <motion.button
            onClick={() => onNavigate('home')}
            className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </motion.button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Leaderboard</h1>
            <p className="text-gray-600">See how you rank among eco warriors!</p>
          </div>
        </div>
      </motion.div>

      <div className="px-6 pb-24">
        {/* Tabs */}
        <motion.div
          className="bg-white rounded-2xl p-2 mb-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="grid grid-cols-4 gap-1">
            {tabs.map((tab) => (
              <motion.button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex flex-col items-center space-y-1 p-3 rounded-xl transition-all ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-yellow-400 to-orange-500 text-white shadow-lg'
                    : 'text-gray-600 hover:bg-gray-50'
                }`}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <tab.icon className="w-5 h-5" />
                <span className="text-xs font-medium">{tab.label}</span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Top 3 Podium */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex items-end justify-center space-x-4 mb-6">
            {leaderboardData.slice(0, 3).map((user, index) => {
              const heights = ['h-24', 'h-32', 'h-20'];
              const positions = [1, 0, 2]; // 2nd, 1st, 3rd
              const actualRank = positions[index] + 1;
              
              return (
                <motion.div
                  key={user.uid}
                  className={`flex flex-col items-center ${heights[index]} justify-end`}
                  initial={{ opacity: 0, y: 50 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: 0.1 * index }}
                >
                  <div className="relative mb-2 rounded-full">
                    <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center text-2xl shadow-lg">
                      {user.photoURL ? (
                        <img src={user.photoURL} alt="Avatar" className="w-14 h-14 rounded-full object-cover" />
                      ) : (
                        '🌱'
                      )}
                    </div>
                    {actualRank === 1 && (
                      <motion.div
                        className="absolute -top-2 -right-2"
                        animate={{ rotate: [0, 10, -10, 0] }}
                        transition={{ duration: 2, repeat: Infinity }}
                      >
                        <Crown className="w-6 h-6 text-yellow-500" />
                      </motion.div>
                    )}
                  </div>
                  <div className="text-center mb-2">
                    <div className="font-bold text-gray-800 text-sm">{user.displayName}</div>
                    <div className="text-xs text-gray-600">{user.weeklyScore} pts</div>
                  </div>
                  <div className={`w-20 bg-gradient-to-t ${
                    actualRank === 1 ? 'from-yellow-400 to-yellow-500' :
                    actualRank === 2 ? 'from-gray-300 to-gray-400' :
                    'from-amber-500 to-amber-600'
                  } rounded-t-lg flex items-center justify-center text-white font-bold ${heights[index]}`}>
                    {actualRank}
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Full Leaderboard */}
        <motion.div
          className="bg-white rounded-2xl shadow-lg overflow-hidden"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <div className="p-4 bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
            <h3 className="font-bold text-lg">
              {activeTab.charAt(0).toUpperCase() + activeTab.slice(1)} Leaderboard
            </h3>
          </div>
          
          {loading && activeTab === 'friends' ? (
            <div className="p-8 text-center">
              <div className="w-8 h-8 border-4 border-yellow-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-gray-600">Loading leaderboard...</p>
            </div>
          ) : currentData.length === 0 ? (
            <div className="p-8 text-center">
              <div className="text-4xl mb-4">🌱</div>
              <h3 className="font-semibold text-gray-800 mb-2">No players yet</h3>
              <p className="text-gray-600 text-sm">Complete challenges to appear on the leaderboard!</p>
            </div>
          ) : (
          <div className="divide-y divide-gray-100">
            {currentData.slice(0, 20).map((user, index) => (
              <motion.div
                key={user.uid}
                className="p-4 flex items-center space-x-4 hover:bg-gray-50"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
              >
                <div className="flex items-center justify-center w-8">
                  {getRankIcon(index + 1)}
                </div>
                <div className="w-12 h-12 rounded-full flex items-center justify-center text-xl">
                  {user.photoURL ? (
                    <img src={user.photoURL} alt="Avatar" className="w-12 h-12 rounded-full object-cover" />
                  ) : (
                    '🌱'
                  )}
                </div>
                <div className="flex-1">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-gray-800">
                      {user.displayName}
                    </span>
                  </div>
                  <div className="text-sm text-gray-600">Level {user.ecoLevel}</div>
                </div>
                <div className="text-right">
                  <div className="font-bold text-gray-800">{user.weeklyScore.toLocaleString()}</div>
                  <div className="text-sm text-gray-600">points</div>
                </div>
                <div className="flex space-x-1">
                  <span className="text-lg">♻️</span>
                  <span className="text-lg">💧</span>
                </div>
              </motion.div>
            ))}
          </div>
          )}
        </motion.div>

        {/* Add Friends Button */}
        {activeTab === 'friends' && (
          <motion.button
            onClick={handleAddFriends}
            className="w-full mt-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 rounded-2xl font-bold shadow-lg flex items-center justify-center space-x-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <UserPlus className="w-6 h-6" />
            <span>Find & Add Friends</span>
          </motion.button>
        )}
      </div>

      {/* Friend Search Modal */}
      {showFriendSearch && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            className="bg-white rounded-2xl max-w-md w-full max-h-[80vh] overflow-hidden"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-800">Find Friends</h2>
                <button
                  onClick={() => {
                    setShowFriendSearch(false);
                    setSearchTerm('');
                    setSearchResults([]);
                  }}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            </div>

            {/* Search */}
            <div className="p-6">
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by name or email..."
                  className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-400 focus:border-transparent"
                />
              </div>

              {/* Search Results */}
              <div className="max-h-60 overflow-y-auto">
                {isSearching ? (
                  <div className="text-center py-8">
                    <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                    <p className="text-gray-600">Searching...</p>
                  </div>
                ) : searchResults.length > 0 ? (
                  <div className="space-y-3">
                    {searchResults.map(searchUser => (
                      <div key={searchUser.uid} className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 rounded-full flex items-center justify-center text-lg">
                            {searchUser.photoURL ? (
                              <img src={searchUser.photoURL} alt="Avatar" className="w-10 h-10 rounded-full object-cover" />
                            ) : (
                              '🌱'
                            )}
                          </div>
                          <div>
                            <div className="font-semibold text-gray-800">{searchUser.displayName}</div>
                            <div className="text-sm text-gray-600">Level {searchUser.ecoLevel}</div>
                          </div>
                        </div>
                        <motion.button
                          onClick={() => handleSendFriendRequest(searchUser.uid)}
                          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg text-sm font-medium"
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                        >
                          Add Friend
                        </motion.button>
                      </div>
                    ))}
                  </div>
                ) : searchTerm.length >= 2 ? (
                  <div className="text-center py-8">
                    <p className="text-gray-600">No users found</p>
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <Search className="w-12 h-12 text-gray-300 mx-auto mb-2" />
                    <p className="text-gray-600">Start typing to search for friends</p>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default LeaderboardPage;