import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User } from 'firebase/auth';
import { submitChallengeProof, getUserWeeklyCompletions, UserProfile } from '../firebase/firestore';
import { 
  ArrowLeft, 
  Clock, 
  Star, 
  Camera, 
  CheckCircle,
  Zap,
  Target,
  Award
} from 'lucide-react';
import ProofSubmissionModal from './ProofSubmissionModal';
import { Challenge, generateNewChallenge, getColorForDifficulty, calculateTimeLeft } from '../utils/challengeSystem';

interface ChallengesPageProps {
  onNavigate: (page: string) => void;
  user?: User;
  userProfile: UserProfile | null;
  onUpdateProfile: (profile: UserProfile) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const ChallengesPage: React.FC<ChallengesPageProps> = ({ onNavigate, user, userProfile, onUpdateProfile, showToast }) => {
  const [completedChallenges, setCompletedChallenges] = useState<number[]>([]);
  const [acceptedChallenges, setAcceptedChallenges] = useState<number[]>([]);
  const [isSubmittingProof, setIsSubmittingProof] = useState(false);
  const [weeklyCompletions, setWeeklyCompletions] = useState<string[]>([]);
  const [challenges, setChallenges] = useState<Challenge[]>([
    {
      id: 1,
      title: "Use a reusable water bottle today",
      description: "Avoid single-use plastic bottles",
      difficulty: "Easy",
      points: 50,
      timeLeft: calculateTimeLeft(),
      color: "from-green-400 to-emerald-500",
      icon: "💧",
      category: "waste-reduction"
    },
    {
      id: 2,
      title: "Take public transport or bike",
      description: "Reduce your carbon footprint",
      difficulty: "Medium",
      points: 100,
      timeLeft: calculateTimeLeft(),
      color: "from-yellow-400 to-orange-500",
      icon: "🚌",
      category: "transportation"
    },
    {
      id: 3,
      title: "Plant a tree or start a garden",
      description: "Contribute to carbon absorption",
      difficulty: "Hard",
      points: 200,
      timeLeft: calculateTimeLeft(),
      color: "from-red-400 to-pink-500",
      icon: "🌱",
      category: "environmental-action"
    }
  ]);
  const [proofModal, setProofModal] = useState<{
    isOpen: boolean;
    challengeId: number | null;
    challengeTitle: string;
    challengePoints: number;
  }>({
    isOpen: false,
    challengeId: null,
    challengeTitle: '',
    challengePoints: 0
  });

  // Load weekly completions on mount
  React.useEffect(() => {
    if (user) {
      getUserWeeklyCompletions(user.uid).then(completions => {
        setWeeklyCompletions(completions);
        // Mark challenges as completed if they're in weekly completions
        const completedIds = challenges
          .filter(c => completions.includes(c.id.toString()))
          .map(c => c.id);
        setCompletedChallenges(completedIds);
      });
    }
  }, [user, challenges]);
  const replaceChallenge = (challengeId: number, difficulty: Challenge['difficulty']) => {
    const newChallengeData = generateNewChallenge(difficulty, completedChallenges);
    const newChallenge: Challenge = {
      id: Date.now(), // Generate new unique ID
      title: newChallengeData.title!,
      description: newChallengeData.description!,
      difficulty,
      points: newChallengeData.points!,
      timeLeft: calculateTimeLeft(),
      color: getColorForDifficulty(difficulty),
      icon: newChallengeData.icon!,
      category: newChallengeData.category!
    };

    setChallenges(prev => 
      prev.map(challenge => 
        challenge.id === challengeId ? newChallenge : challenge
      )
    );
  };

  const handleProofSubmission = async (proof: string, description: string): Promise<{ success: boolean; message?: string }> => {
    const { challengeId, challengePoints } = proofModal;
    if (!challengeId || !user) return { success: false, message: 'Invalid challenge or user' };

    const challenge = challenges.find(c => c.id === challengeId);
    if (!challenge) return { success: false, message: 'Challenge not found' };

    setIsSubmittingProof(true);
    
    try {
      const result = await submitChallengeProof(
        user,
        challengeId.toString(),
        challenge.title,
        challenge.difficulty,
        challengePoints,
        description,
        proof || undefined
      );
      
      if (result.success && result.newUserProfile) {
        // Mark challenge as completed
        setCompletedChallenges(prev => [...prev, challengeId]);
        setWeeklyCompletions(prev => [...prev, challengeId.toString()]);
        
        // Update user profile
        onUpdateProfile(result.newUserProfile);
        
        // Replace with new challenge after a delay
        setTimeout(() => {
          replaceChallenge(challengeId, challenge.difficulty);
        }, 2000);
        
        return { success: true };
      } else {
        return { success: false, message: 'Failed to submit challenge proof' };
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      return { success: false, message: errorMessage };
    } finally {
      setIsSubmittingProof(false);
    }
  };

  const handleCompleteChallenge = (challengeId: number) => {
    const challenge = challenges.find(c => c.id === challengeId);
    if (!challenge) return;

    setProofModal({
      isOpen: true,
      challengeId,
      challengeTitle: challenge.title,
      challengePoints: challenge.points
    });
  };

  const handleAcceptChallenge = (challengeId: number) => {
    setAcceptedChallenges(prev => [...prev, challengeId]);
  };

  const closeProofModal = () => {
    setProofModal({
      isOpen: false,
      challengeId: null,
      challengeTitle: '',
      challengePoints: 0
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100">
      {/* Header */}
      <motion.div
        className="bg-white shadow-lg rounded-b-3xl p-6 mb-6"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center space-x-4">
          <motion.button
            onClick={() => onNavigate('home')}
            className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <ArrowLeft className="w-6 h-6 text-gray-600" />
          </motion.button>
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Weekly Challenges</h1>
            <p className="text-gray-600">Complete challenges to earn points!</p>
          </div>
        </div>
      </motion.div>

      <div className="px-6 pb-24">
        {/* Progress Overview */}
        <motion.div
          className="bg-white rounded-2xl p-6 mb-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-bold text-gray-800">This Week's Progress</h2>
            <div className="flex items-center space-x-2">
              <Star className="w-5 h-5 text-yellow-500" />
              <span className="font-bold text-gray-800">{completedChallenges.length}/3</span>
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3">
            <motion.div
              className="bg-gradient-to-r from-green-400 to-emerald-500 h-3 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${(completedChallenges.length / 3) * 100}%` }}
              transition={{ duration: 0.8 }}
            />
          </div>
          <p className="text-sm text-gray-600 mt-2">
            {completedChallenges.length === 3 
              ? "🎉 All challenges completed!" 
              : `${3 - completedChallenges.length} challenges remaining`
            }
          </p>
        </motion.div>

        {/* Challenges List */}
        <div className="space-y-4">
          {challenges.map((challenge, index) => {
            const isCompleted = completedChallenges.includes(challenge.id);
            const isCompletedThisWeek = weeklyCompletions.includes(challenge.id.toString());
            const isAccepted = acceptedChallenges.includes(challenge.id);
            
            return (
              <motion.div
                key={challenge.id}
                className={`bg-white rounded-2xl p-6 shadow-lg ${
                  isCompleted || isCompletedThisWeek ? 'ring-2 ring-green-400 bg-green-50' : ''
                }`}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.1 * index }}
                whileHover={{ scale: isCompleted || isCompletedThisWeek ? 1 : 1.02 }}
              >
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center space-x-3">
                    <div className="text-2xl">{challenge.icon}</div>
                    <div>
                      <h3 className={`font-bold text-lg ${
                        isCompleted || isCompletedThisWeek ? 'text-green-700' : 'text-gray-800'
                      }`}>
                        {challenge.title}
                      </h3>
                      <p className="text-gray-600 text-sm">{challenge.description}</p>
                    </div>
                  </div>
                  {(isCompleted || isCompletedThisWeek) && (
                    <motion.div
                      initial={{ scale: 0 }}
                      animate={{ scale: 1 }}
                      transition={{ type: "spring", duration: 0.5 }}
                    >
                      <CheckCircle className="w-8 h-8 text-green-500" />
                    </motion.div>
                  )}
                </div>

                <div className="flex items-center justify-between mb-4">
                  <div className="flex items-center space-x-4">
                    <div className={`px-3 py-1 rounded-full text-xs font-medium bg-gradient-to-r ${challenge.color} text-white`}>
                      {challenge.difficulty}
                    </div>
                    <div className="flex items-center space-x-1 text-yellow-600">
                      <Zap className="w-4 h-4" />
                      <span className="font-bold">{challenge.points} pts</span>
                    </div>
                  </div>
                  <div className="flex items-center space-x-1 text-gray-500">
                    <Clock className="w-4 h-4" />
                    <span className="text-sm">{challenge.timeLeft}</span>
                  </div>
                </div>

                {!isCompleted && !isCompletedThisWeek && !isAccepted ? (
                  <div className="flex space-x-3">
                    <motion.button
                      onClick={() => handleAcceptChallenge(challenge.id)}
                      className={`w-full bg-gradient-to-r ${challenge.color} text-white py-3 px-4 rounded-xl font-medium hover:shadow-lg`}
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      Accept Challenge
                    </motion.button>
                  </div>
                ) : !isCompleted && !isCompletedThisWeek && isAccepted ? (
                  <div className="flex space-x-3">
                    <motion.button
                      onClick={() => handleCompleteChallenge(challenge.id)}
                      className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 px-4 rounded-xl font-medium hover:shadow-lg flex items-center justify-center space-x-2"
                      whileHover={{ scale: 1.02 }}
                      whileTap={{ scale: 0.98 }}
                    >
                      <CheckCircle className="w-5 h-5" />
                      <span>Complete Challenge</span>
                    </motion.button>
                  </div>
                ) : (
                  <motion.div
                    className="bg-green-100 border border-green-200 rounded-xl p-3 text-center"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: 0.2 }}
                  >
                    <div className="flex items-center justify-center space-x-2 text-green-700">
                      <Award className="w-5 h-5" />
                      <span className="font-medium">Challenge Completed! +{challenge.points} points</span>
                    </div>
                  </motion.div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* Weekly Bonus */}
        <motion.div
          className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-lg mt-6"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <div className="flex items-center space-x-3 mb-2">
            <Target className="w-6 h-6" />
            <h3 className="font-bold text-lg">Weekly Bonus</h3>
          </div>
          <p className="text-sm opacity-90 mb-3">
            Complete all 3 challenges to unlock a 100-point bonus!
          </p>
          {weeklyCompletions.length >= 3 && (
            <motion.div
              className="bg-white/20 rounded-lg px-4 py-2 text-center"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.5 }}
            >
              <span className="font-bold">🎉 Bonus Unlocked! +100 points</span>
            </motion.div>
          )}
        </motion.div>
      </div>
      
      <ProofSubmissionModal
        isOpen={proofModal.isOpen}
        onClose={closeProofModal}
        onSubmit={handleProofSubmission}
        challengeTitle={proofModal.challengeTitle}
        challengePoints={proofModal.challengePoints}
        isSubmitting={isSubmittingProof}
        showToast={showToast}
      />
    </div>
  );
};

export default ChallengesPage;