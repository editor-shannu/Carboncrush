import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trophy, Crown, Medal, Award, Calendar } from 'lucide-react';
import { getWeeklyLeaderboard, saveCommunityPost, getCurrentWeek } from '../utils/challengeSystem';

interface WeeklyLeaderboardAnnouncementProps {
  onClose: () => void;
}

const WeeklyLeaderboardAnnouncement: React.FC<WeeklyLeaderboardAnnouncementProps> = ({ onClose }) => {
  const [winners, setWinners] = useState<any[]>([]);
  const [currentWeek, setCurrentWeek] = useState('');

  useEffect(() => {
    const week = getCurrentWeek();
    setCurrentWeek(week);
    
    const leaderboard = getWeeklyLeaderboard(week);
    const topThree = leaderboard.slice(0, 3);
    setWinners(topThree);

    // Auto-post to community
    if (topThree.length > 0) {
      const announcementPost = {
        id: Date.now(),
        user: {
          name: 'Carbon Crush System',
          avatar: '🏆',
          level: 'ADMIN'
        },
        content: `🎉 Weekly Challenge Winners Announced! 🎉\n\nCongratulations to our top eco warriors for ${week}:\n\n🥇 ${topThree[0]?.userName} - ${topThree[0]?.totalPoints} points\n${topThree[1] ? `🥈 ${topThree[1].userName} - ${topThree[1].totalPoints} points\n` : ''}${topThree[2] ? `🥉 ${topThree[2].userName} - ${topThree[2].totalPoints} points\n` : ''}\nKeep up the amazing work, everyone! 🌱`,
        image: null,
        likes: Math.floor(Math.random() * 50) + 20,
        comments: Math.floor(Math.random() * 15) + 5,
        timeAgo: 'Just now',
        badges: ['🏆', '🌍', '⭐'],
        isSystemPost: true,
        weeklyAnnouncement: {
          week,
          winners: topThree
        }
      };

      saveCommunityPost(announcementPost);
    }
  }, []);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 0: return <Crown className="w-8 h-8 text-yellow-500" />;
      case 1: return <Medal className="w-8 h-8 text-gray-400" />;
      case 2: return <Award className="w-8 h-8 text-amber-600" />;
      default: return null;
    }
  };

  const getRankEmoji = (rank: number) => {
    switch (rank) {
      case 0: return '🥇';
      case 1: return '🥈';
      case 2: return '🥉';
      default: return '';
    }
  };

  return (
    <AnimatePresence>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
        <motion.div
          className="bg-white rounded-3xl max-w-md w-full max-h-[90vh] overflow-y-auto"
          initial={{ opacity: 0, scale: 0.8, y: 50 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.8, y: 50 }}
          transition={{ duration: 0.5, type: "spring" }}
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-6 text-white text-center rounded-t-3xl">
            <motion.div
              animate={{ rotate: [0, 10, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              className="inline-block mb-4"
            >
              <Trophy className="w-16 h-16 mx-auto" />
            </motion.div>
            <h1 className="text-2xl font-bold mb-2">🎉 Weekly Winners! 🎉</h1>
            <div className="flex items-center justify-center space-x-2 text-sm opacity-90">
              <Calendar className="w-4 h-4" />
              <span>{currentWeek}</span>
            </div>
          </div>

          {/* Winners */}
          <div className="p-6">
            {winners.length > 0 ? (
              <div className="space-y-4">
                {winners.map((winner, index) => (
                  <motion.div
                    key={winner.userId}
                    className={`flex items-center space-x-4 p-4 rounded-2xl ${
                      index === 0 ? 'bg-gradient-to-r from-yellow-50 to-orange-50 border-2 border-yellow-200' :
                      index === 1 ? 'bg-gray-50 border border-gray-200' :
                      'bg-amber-50 border border-amber-200'
                    }`}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.5, delay: index * 0.2 }}
                  >
                    <div className="flex items-center justify-center w-12 h-12">
                      {getRankIcon(index)}
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <span className="text-2xl">{getRankEmoji(index)}</span>
                        <span className="font-bold text-gray-800">{winner.userName}</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        {winner.totalPoints} points • {winner.challengesCompleted} challenges
                      </div>
                    </div>

                    {index === 0 && (
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity }}
                        className="text-2xl"
                      >
                        👑
                      </motion.div>
                    )}
                  </motion.div>
                ))}

                {/* Celebration Message */}
                <motion.div
                  className="bg-green-50 border border-green-200 rounded-2xl p-4 text-center mt-6"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: 0.8 }}
                >
                  <div className="text-green-800 font-semibold mb-2">
                    🌱 Amazing work, eco warriors! 🌱
                  </div>
                  <div className="text-sm text-green-700">
                    Your dedication to sustainability is making a real difference. 
                    Keep up the fantastic work and let's make next week even better!
                  </div>
                </motion.div>
              </div>
            ) : (
              <div className="text-center py-8">
                <div className="text-6xl mb-4">🌱</div>
                <h3 className="text-lg font-semibold text-gray-800 mb-2">
                  No challenges completed yet
                </h3>
                <p className="text-gray-600 text-sm">
                  Be the first to complete a challenge this week!
                </p>
              </div>
            )}

            {/* Close Button */}
            <motion.button
              onClick={onClose}
              className="w-full mt-6 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-4 px-6 rounded-2xl font-bold"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Continue Your Eco Journey
            </motion.button>
          </div>
        </motion.div>

        {/* Confetti Animation */}
        <div className="fixed inset-0 pointer-events-none">
          {[...Array(50)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-3 h-3 rounded-full"
              style={{
                backgroundColor: ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4'][i % 5],
                left: `${Math.random() * 100}%`,
                top: '-10px'
              }}
              animate={{
                y: window.innerHeight + 20,
                rotate: 360,
                opacity: [1, 1, 0]
              }}
              transition={{
                duration: 3,
                delay: Math.random() * 2,
                ease: "easeOut"
              }}
            />
          ))}
        </div>
      </div>
    </AnimatePresence>
  );
};

export default WeeklyLeaderboardAnnouncement;