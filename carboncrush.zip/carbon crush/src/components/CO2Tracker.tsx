import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  Square, 
  MapPin, 
  Clock, 
  Zap, 
  Car,
  Bike,
  Bus,
  AlertCircle,
  CheckCircle,
  TrendingDown,
  Upload,
  FileText,
  Camera,
  Settings,
  X
} from 'lucide-react';

interface Position {
  latitude: number;
  longitude: number;
  timestamp: number;
}

interface RideData {
  id: string;
  startTime: number;
  endTime: number;
  duration: number;
  distance: number;
  co2Emitted: number;
  vehicleType: string;
  startLocation: Position;
  endLocation: Position;
  co2PerKm: number;
}

interface PUCData {
  co2Percentage: number;
  co2PerKm: number;
  uploadDate: number;
  fileName: string;
}

interface CO2TrackerProps {
  onRideComplete?: (rideData: RideData) => void;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const CO2Tracker: React.FC<CO2TrackerProps> = ({ onRideComplete, showToast }) => {
  const [isTracking, setIsTracking] = useState(false);
  const [startTime, setStartTime] = useState<number | null>(null);
  const [currentTime, setCurrentTime] = useState(Date.now());
  const [startPosition, setStartPosition] = useState<Position | null>(null);
  const [endPosition, setEndPosition] = useState<Position | null>(null);
  const [vehicleType, setVehicleType] = useState('car');
  const [lastRide, setLastRide] = useState<RideData | null>(null);
  const [locationPermission, setLocationPermission] = useState<'granted' | 'denied' | 'prompt'>('prompt');
  const [showPUCUpload, setShowPUCUpload] = useState(false);
  const [pucData, setPucData] = useState<PUCData | null>(null);
  const [manualCO2, setManualCO2] = useState(192);
  const [showManualInput, setShowManualInput] = useState(false);
  const [showRideSummary, setShowRideSummary] = useState(false);
  const [isProcessingPUC, setIsProcessingPUC] = useState(false);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Vehicle emission factors (grams CO₂ per km) - fallback values
  const defaultEmissionFactors = {
    car: 192, // Average petrol car
    bike: 0,  // Bicycle produces no direct emissions
    bus: 80,  // Public bus per person
    motorcycle: 120,
    walking: 0
  };

  const vehicleOptions = [
    { id: 'car', name: 'Car', icon: Car, factor: 192 },
    { id: 'bike', name: 'Bike', icon: Bike, factor: 0 },
    { id: 'bus', name: 'Bus', icon: Bus, factor: 80 },
    { id: 'motorcycle', name: 'Motorcycle', icon: Car, factor: 120 },
    { id: 'walking', name: 'Walking', icon: MapPin, factor: 0 }
  ];

  useEffect(() => {
    // Check if we're on HTTPS (required for geolocation)
    const isSecure = window.location.protocol === 'https:' || window.location.hostname === 'localhost';
    
    if (!isSecure) {
      showToast('HTTPS required for location access. Please use a secure connection.', 'error');
      setLocationPermission('denied');
      return;
    }

    // Check geolocation support
    if (!navigator.geolocation) {
      showToast('Geolocation is not supported by this browser', 'error');
      setLocationPermission('denied');
      return;
    }

    // Check geolocation permission status
    if ('permissions' in navigator) {
      navigator.permissions.query({ name: 'geolocation' }).then((result) => {
        console.log('Geolocation permission state:', result.state);
        setLocationPermission(result.state as 'granted' | 'denied' | 'prompt');
        
        // Listen for permission changes
        result.addEventListener('change', () => {
          console.log('Geolocation permission changed to:', result.state);
          setLocationPermission(result.state as 'granted' | 'denied' | 'prompt');
        });
      }).catch(err => {
        console.warn('Could not query geolocation permission:', err);
        setLocationPermission('prompt');
      });
    } else {
      setLocationPermission('prompt');
    }

    // Load saved PUC data
    const savedPUC = localStorage.getItem('pucData');
    if (savedPUC) {
      setPucData(JSON.parse(savedPUC));
    }

    // Load manual CO2 setting
    const savedManualCO2 = localStorage.getItem('manualCO2');
    if (savedManualCO2) {
      setManualCO2(parseInt(savedManualCO2));
    }
  }, []);

  useEffect(() => {
    if (isTracking && startTime) {
      timerRef.current = setInterval(() => {
        setCurrentTime(Date.now());
      }, 1000);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [isTracking, startTime]);

  const getCurrentPosition = (): Promise<Position> => {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) {
        reject(new Error('Geolocation is not supported by this browser'));
        return;
      }

      // Check if we're on HTTPS
      const isSecure = window.location.protocol === 'https:' || window.location.hostname === 'localhost';
      if (!isSecure) {
        reject(new Error('HTTPS connection required for location access. Please use a secure connection.'));
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          console.log('Location obtained:', {
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            accuracy: position.coords.accuracy
          });
          resolve({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
            timestamp: Date.now()
          });
        },
        (error) => {
          console.error('Geolocation error:', error);
          let errorMessage = 'Location access failed. ';
          
          switch (error.code) {
            case error.PERMISSION_DENIED:
              errorMessage += 'Location access denied. Please:\n1. Click the location icon in your browser\'s address bar\n2. Select "Allow" for location access\n3. Refresh the page and try again';
              setLocationPermission('denied');
              break;
            case error.POSITION_UNAVAILABLE:
              errorMessage += 'Location unavailable. Please:\n1. Enable GPS/Location Services on your device\n2. Ensure you have a clear view of the sky if outdoors\n3. Try again in a few moments';
              break;
            case error.TIMEOUT:
              errorMessage += 'Location request timed out. Please:\n1. Ensure you have a stable internet connection\n2. Try moving to an area with better GPS signal\n3. Try again';
              break;
            default:
              errorMessage += 'An unknown location error occurred. Please check your device settings and try again.';
              break;
          }
          
          reject(new Error(errorMessage));
        },
        {
          enableHighAccuracy: true,
          timeout: 20000,  // 20 second timeout
          maximumAge: 60000 // Accept cached location up to 1 minute old
        }
      );
    });
  };

  const calculateDistance = (pos1: Position, pos2: Position): number => {
    const R = 6371; // Earth's radius in kilometers
    const dLat = (pos2.latitude - pos1.latitude) * Math.PI / 180;
    const dLon = (pos2.longitude - pos1.longitude) * Math.PI / 180;
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(pos1.latitude * Math.PI / 180) * Math.cos(pos2.latitude * Math.PI / 180) * 
      Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c; // Distance in kilometers
  };

  const simulateOCR = (file: File): Promise<number> => {
    return new Promise((resolve) => {
      // Simulate OCR processing delay
      setTimeout(() => {
        // Simulate extracting CO2 percentage from PUC certificate
        // In real implementation, this would use actual OCR service
        const mockCO2Percentages = [8.5, 9.2, 10.1, 11.3, 9.8, 8.9, 10.5];
        const randomCO2 = mockCO2Percentages[Math.floor(Math.random() * mockCO2Percentages.length)];
        resolve(randomCO2);
      }, 2000);
    });
  };

  const convertCO2PercentageToEmission = (co2Percentage: number): number => {
    // Convert CO2 percentage to grams per km
    // This is a simplified conversion - in reality, this would be more complex
    // Higher CO2 percentage = higher emissions
    const baseEmission = 192; // Base emission for average car
    const factor = co2Percentage / 10; // Normalize percentage
    return Math.round(baseEmission * factor);
  };

  const handlePUCUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    // Validate file type
    const validTypes = ['image/jpeg', 'image/png', 'image/jpg', 'application/pdf'];
    if (!validTypes.includes(file.type)) {
      showToast('Please upload a valid image (JPG, PNG) or PDF file', 'error');
      return;
    }

    setIsProcessingPUC(true);

    try {
      // Simulate OCR processing
      const co2Percentage = await simulateOCR(file);
      const co2PerKm = convertCO2PercentageToEmission(co2Percentage);

      const newPUCData: PUCData = {
        co2Percentage,
        co2PerKm,
        uploadDate: Date.now(),
        fileName: file.name
      };

      setPucData(newPUCData);
      localStorage.setItem('pucData', JSON.stringify(newPUCData));
      setShowPUCUpload(false);
      setIsProcessingPUC(false);

      showToast(`PUC Certificate processed! CO₂: ${co2Percentage}% Vol, Rate: ${co2PerKm}g/km`, 'success');
    } catch (err) {
      showToast('Failed to process PUC certificate. Please try again.', 'error');
      setIsProcessingPUC(false);
    }
  };

  const handleManualCO2Save = () => {
    localStorage.setItem('manualCO2', manualCO2.toString());
    setShowManualInput(false);
    showToast(`Manual CO₂ emission rate set to ${manualCO2}g/km`, 'success');
  };

  const getEmissionFactor = (): number => {
    if (vehicleType === 'bike' || vehicleType === 'walking') {
      return 0;
    }
    
    if (vehicleType === 'car' && pucData) {
      return pucData.co2PerKm;
    }
    
    if (vehicleType === 'car') {
      return manualCO2;
    }
    
    return defaultEmissionFactors[vehicleType as keyof typeof defaultEmissionFactors];
  };

  const handleStartTracking = async () => {
    // Check permission first
    if (locationPermission === 'denied') {
      showToast('Location access is required for CO₂ tracking. Please enable location in your browser settings and refresh the page.', 'error');
      return;
    }

    try {
      showToast('Getting your location... Please wait', 'info');
      
      // Check permission again before requesting location
      if ('permissions' in navigator) {
        const permission = await navigator.permissions.query({ name: 'geolocation' });
        if (permission.state === 'denied') {
          setLocationPermission('denied');
          throw new Error('Location access denied. Please enable location in your browser settings and refresh the page.');
        }
      }

      const position = await getCurrentPosition();
      console.log('Start position:', position);
      
      setStartPosition(position);
      setStartTime(Date.now());
      setIsTracking(true);
      setLocationPermission('granted');
      
      showToast(`Tracking started! Vehicle: ${vehicleOptions.find(v => v.id === vehicleType)?.name}`, 'success');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get location';
      console.error('Start tracking error:', err);
      
      // Only set to denied if it's actually a permission error
      if (errorMessage.includes('denied') || errorMessage.includes('PERMISSION_DENIED')) {
        setLocationPermission('denied');
      }
      
      showToast(errorMessage, 'error');
    }
  };

  const handleStopTracking = async () => {
    if (!startTime || !startPosition) return;

    try {
      showToast('Getting final location...', 'info');
      const position = await getCurrentPosition();
      console.log('End position:', position);
      console.log('Start position was:', startPosition);
      
      setEndPosition(position);
      
      const endTime = Date.now();
      const duration = (endTime - startTime) / 1000; // Duration in seconds
      const distance = calculateDistance(startPosition, position);
      
      console.log('Calculated distance:', distance, 'km');
      console.log('Duration:', duration, 'seconds');
      
      // Check if there was significant movement (at least 50 meters)
      if (distance < 0.05) {
        showToast('No significant movement detected (less than 50m). Try a longer journey.', 'error');
        setIsTracking(false);
        setStartTime(null);
        setStartPosition(null);
        return;
      }

      const emissionFactor = getEmissionFactor();
      const co2Emitted = distance * emissionFactor;
      
      console.log('Emission factor:', emissionFactor, 'g/km');
      console.log('CO2 emitted:', co2Emitted, 'g');
      
      const rideData: RideData = {
        id: Date.now().toString(),
        startTime,
        endTime,
        duration,
        distance,
        co2Emitted,
        vehicleType,
        startLocation: startPosition,
        endLocation: position,
        co2PerKm: emissionFactor
      };

      setLastRide(rideData);
      setIsTracking(false);
      setStartTime(null);
      setStartPosition(null);
      setEndPosition(null);
      setShowRideSummary(true);
      
      const co2Display = co2Emitted > 1000 
        ? `${(co2Emitted / 1000).toFixed(2)}kg` 
        : `${co2Emitted.toFixed(0)}g`;
      
      showToast(`Journey complete! ${distance.toFixed(2)}km, CO₂: ${co2Display}`, 'success');

      if (onRideComplete) {
        onRideComplete(rideData);
      }
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to get final location';
      console.error('Stop tracking error:', err);
      showToast(errorMessage, 'error');
    }
  };

  const formatDuration = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = Math.floor(seconds % 60);
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const formatDurationText = (seconds: number): string => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  const currentDuration = startTime ? (currentTime - startTime) / 1000 : 0;

  return (
    <div className="bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl p-6 text-white shadow-lg">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-3">
          <div className="w-3 h-3 bg-red-400 rounded-full animate-pulse" />
          <h3 className="font-bold text-lg">🚗 Ride CO₂ Tracker</h3>
        </div>
        <motion.button
          onClick={() => setShowPUCUpload(true)}
          className="p-2 bg-white/20 hover:bg-white/30 rounded-lg transition-colors"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          title="Upload PUC Certificate"
        >
          <Settings className="w-5 h-5" />
        </motion.button>
      </div>
      
      <p className="text-sm opacity-90 mb-4">
        Track your journey's CO₂ emissions with precision!
      </p>

      {/* PUC Status */}
      {pucData ? (
        <div className="bg-white/20 rounded-xl p-3 mb-4">
          <div className="flex items-center space-x-2 mb-1">
            <CheckCircle className="w-4 h-4 text-green-300" />
            <span className="text-sm font-medium">PUC Certificate Active</span>
          </div>
          <div className="text-xs opacity-75">
            CO₂: {pucData.co2Percentage}% Vol • {pucData.co2PerKm}g/km
          </div>
        </div>
      ) : vehicleType === 'car' && (
        <div className="bg-yellow-500/20 border border-yellow-400/30 rounded-xl p-3 mb-4">
          <div className="flex items-center space-x-2 mb-2">
            <AlertCircle className="w-4 h-4 text-yellow-300" />
            <span className="text-sm font-medium">Upload PUC for Accurate Tracking</span>
          </div>
          <p className="text-xs opacity-75 mb-2">
            Upload your latest PUC certificate to auto-calculate CO₂ emission.
          </p>
          <div className="flex space-x-2">
            <motion.button
              onClick={() => setShowPUCUpload(true)}
              className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg text-xs font-medium"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Upload PUC
            </motion.button>
            <motion.button
              onClick={() => setShowManualInput(true)}
              className="bg-white/20 hover:bg-white/30 px-3 py-1 rounded-lg text-xs font-medium"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              Manual Entry
            </motion.button>
          </div>
        </div>
      )}

      {/* Vehicle Selection */}
      {!isTracking && (
        <div className="mb-4">
          <p className="text-sm mb-2 opacity-90">Select your vehicle:</p>
          <div className="grid grid-cols-3 gap-2">
            {vehicleOptions.slice(0, 3).map((vehicle) => (
              <motion.button
                key={vehicle.id}
                onClick={() => setVehicleType(vehicle.id)}
                className={`p-2 rounded-lg text-xs font-medium transition-all ${
                  vehicleType === vehicle.id
                    ? 'bg-white text-purple-600'
                    : 'bg-white/20 hover:bg-white/30'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <vehicle.icon className="w-4 h-4 mx-auto mb-1" />
                {vehicle.name}
              </motion.button>
            ))}
          </div>
          <div className="grid grid-cols-2 gap-2 mt-2">
            {vehicleOptions.slice(3).map((vehicle) => (
              <motion.button
                key={vehicle.id}
                onClick={() => setVehicleType(vehicle.id)}
                className={`p-2 rounded-lg text-xs font-medium transition-all ${
                  vehicleType === vehicle.id
                    ? 'bg-white text-purple-600'
                    : 'bg-white/20 hover:bg-white/30'
                }`}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <vehicle.icon className="w-4 h-4 mx-auto mb-1" />
                {vehicle.name}
              </motion.button>
            ))}
          </div>
        </div>
      )}

      {/* Live Tracking Display */}
      <AnimatePresence>
        {isTracking && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="bg-white/20 rounded-xl p-4 mb-4"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
                <span className="text-sm font-medium">Tracking Active</span>
              </div>
              <div className="flex items-center space-x-1">
                <Clock className="w-4 h-4" />
                <span className="font-mono text-lg">{formatDuration(currentDuration)}</span>
              </div>
            </div>
            <div className="text-xs opacity-75">
              Vehicle: {vehicleOptions.find(v => v.id === vehicleType)?.name} • 
              Emission Rate: {getEmissionFactor()}g/km
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Control Buttons */}
      <div className="flex space-x-3">
        {!isTracking ? (
          <motion.button
            onClick={handleStartTracking}
            disabled={locationPermission === 'denied'}
            className="flex-1 bg-white text-purple-600 py-3 px-4 rounded-xl font-bold flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed"
            whileHover={{ scale: locationPermission !== 'denied' ? 1.02 : 1 }}
            whileTap={{ scale: locationPermission !== 'denied' ? 0.98 : 1 }}
          >
            <Play className="w-5 h-5" />
            <span>Start Tracking</span>
          </motion.button>
        ) : (
          <motion.button
            onClick={handleStopTracking}
            className="flex-1 bg-red-500 hover:bg-red-600 text-white py-3 px-4 rounded-xl font-bold flex items-center justify-center space-x-2"
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Square className="w-5 h-5" />
            <span>Stop Tracking</span>
          </motion.button>
        )}
      </div>

      {locationPermission === 'denied' && (
        <div className="mt-3 p-3 bg-red-500/20 rounded-xl border border-red-400/30">
          <div className="text-center">
            <p className="text-xs font-medium mb-2">📍 Location Access Required</p>
            <p className="text-xs opacity-90 mb-2">
              To track CO₂ emissions, please:
            </p>
            <ol className="text-xs opacity-90 text-left space-y-1">
              <li>1. Click the location icon 📍 in your browser's address bar</li>
              <li>2. Select "Allow" for location access</li>
              <li>3. Refresh the page and try again</li>
            </ol>
          </div>
        </div>
      )}
      
      {/* Location Help */}
      {locationPermission === 'prompt' && (
        <div className="mt-3 p-3 bg-blue-500/20 rounded-xl">
          <p className="text-xs text-center mb-2">
            💡 <strong>Ready to track:</strong> Click "Start Tracking" to begin monitoring your journey.
          </p>
          <p className="text-xs text-center opacity-90">
            We'll use GPS to measure distance and calculate CO₂ emissions based on your vehicle type.
          </p>
        </div>
      )}

      {/* Success State */}
      {locationPermission === 'granted' && !isTracking && (
        <div className="mt-3 p-3 bg-green-500/20 rounded-xl border border-green-400/30">
          <p className="text-xs text-center">
            ✅ <strong>Location access granted!</strong> Ready to track your CO₂ emissions.
          </p>
        </div>
      )}

      {/* PUC Upload Modal */}
      <AnimatePresence>
        {showPUCUpload && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <motion.div
              className="bg-white rounded-2xl max-w-md w-full p-6 text-gray-800"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">Upload PUC Certificate</h3>
                <button
                  onClick={() => setShowPUCUpload(false)}
                  className="p-1 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <p className="text-sm text-gray-600 mb-4">
                Upload your latest PUC certificate to automatically extract CO₂ emission data.
              </p>

              <div className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-xl p-6 text-center">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*,.pdf"
                    onChange={handlePUCUpload}
                    className="hidden"
                  />
                  
                  {isProcessingPUC ? (
                    <div className="space-y-3">
                      <div className="w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto" />
                      <p className="text-sm font-medium">Processing PUC Certificate...</p>
                      <p className="text-xs text-gray-500">Extracting CO₂ data using OCR</p>
                    </div>
                  ) : (
                    <div className="space-y-3">
                      <FileText className="w-12 h-12 text-gray-400 mx-auto" />
                      <div>
                        <p className="font-medium">Upload PUC Certificate</p>
                        <p className="text-sm text-gray-500">JPG, PNG, or PDF format</p>
                      </div>
                      <motion.button
                        onClick={() => fileInputRef.current?.click()}
                        className="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-lg font-medium"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        Choose File
                      </motion.button>
                    </div>
                  )}
                </div>

                <div className="bg-blue-50 rounded-lg p-3">
                  <p className="text-xs text-blue-800">
                    <strong>What we extract:</strong> CO₂ percentage from the "Petrol Test" or "Gas Test" section of your PUC certificate.
                  </p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Manual CO2 Input Modal */}
      <AnimatePresence>
        {showManualInput && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <motion.div
              className="bg-white rounded-2xl max-w-md w-full p-6 text-gray-800"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold">Manual CO₂ Entry</h3>
                <button
                  onClick={() => setShowManualInput(false)}
                  className="p-1 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              
              <p className="text-sm text-gray-600 mb-4">
                Enter your vehicle's CO₂ emission rate manually.
              </p>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    CO₂ Emission Rate (grams per km)
                  </label>
                  <input
                    type="number"
                    value={manualCO2}
                    onChange={(e) => setManualCO2(parseInt(e.target.value) || 192)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-400 focus:border-transparent"
                    min="0"
                    max="500"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    Default: 192g/km (average petrol car)
                  </p>
                </div>

                <div className="flex space-x-3">
                  <motion.button
                    onClick={() => setShowManualInput(false)}
                    className="flex-1 bg-gray-200 hover:bg-gray-300 text-gray-800 py-2 px-4 rounded-lg font-medium"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Cancel
                  </motion.button>
                  <motion.button
                    onClick={handleManualCO2Save}
                    className="flex-1 bg-purple-500 hover:bg-purple-600 text-white py-2 px-4 rounded-lg font-medium"
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    Save
                  </motion.button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Ride Summary Modal */}
      <AnimatePresence>
        {showRideSummary && lastRide && (
          <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
            <motion.div
              className="bg-white rounded-2xl max-w-md w-full p-6 text-gray-800"
              initial={{ opacity: 0, scale: 0.9, y: 50 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 50 }}
            >
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <h3 className="text-2xl font-bold mb-2">🚴 Ride Summary</h3>
                <p className="text-gray-600">Your journey has been completed!</p>
              </div>

              <div className="space-y-4 mb-6">
                <div className="bg-gray-50 rounded-xl p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-600">
                        {lastRide.distance.toFixed(1)} km
                      </div>
                      <div className="text-sm text-gray-600">Distance</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {formatDurationText(lastRide.duration)}
                      </div>
                      <div className="text-sm text-gray-600">Duration</div>
                    </div>
                  </div>
                </div>

                <div className="bg-gradient-to-r from-red-50 to-orange-50 border border-red-200 rounded-xl p-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-red-600 mb-1">
                      {lastRide.co2Emitted > 1000 
                        ? `${(lastRide.co2Emitted / 1000).toFixed(2)} kg`
                        : `${lastRide.co2Emitted.toFixed(0)} g`
                      }
                    </div>
                    <div className="text-sm text-red-700 font-medium">CO₂ Emitted</div>
                    <div className="text-xs text-red-600 mt-1">
                      Rate: {lastRide.co2PerKm}g/km
                    </div>
                  </div>
                </div>

                {lastRide.co2Emitted === 0 && (
                  <div className="bg-green-50 border border-green-200 rounded-xl p-3 text-center">
                    <div className="text-green-800 font-medium">🌱 Zero Emissions!</div>
                    <div className="text-xs text-green-700">Great choice for the environment!</div>
                  </div>
                )}
              </div>

              <motion.button
                onClick={() => setShowRideSummary(false)}
                className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white py-3 px-4 rounded-xl font-bold"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Continue
              </motion.button>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default CO2Tracker;