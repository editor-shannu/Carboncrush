import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase/config';
import { 
  ArrowLeft, 
  Edit, 
  Award, 
  TrendingUp, 
  Calendar,
  Share,
  Settings,
  Leaf,
  Droplets,
  Recycle,
  Zap,
  TreePine,
  Sun,
  User as UserIcon,
  Bell,
  Shield,
  Palette,
  X
} from 'lucide-react';

interface UserProfile {
  displayName: string;
  uid: string;
  ecoLevel: number;
  weeklyScore: number;
  totalScore: number;
  dayStreak: number;
  joinedAt?: any;
}

interface ProfilePageProps {
  onNavigate: (page: string) => void;
  user?: any;
  userProfile: UserProfile | null;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate, user, userProfile, showToast }) => {
  const [isEditingProfile, setIsEditingProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [editForm, setEditForm] = useState({
    displayName: '',
    bio: ''
  });
  const [settingsForm, setSettingsForm] = useState({
    notifications: true,
    privacy: 'public',
    theme: 'light'
  });

  React.useEffect(() => {
    if (userProfile) {
      setEditForm({
        displayName: userProfile.displayName,
        bio: 'Passionate about sustainable living and making a positive impact on our planet. Every small action counts! 🌍✨'
      });
    }
  }, [userProfile]);

  const userStats = userProfile ? {
    name: userProfile.displayName,
    uniqueId: `#ECO${userProfile.uid.slice(-4).toUpperCase()}`,
    level: userProfile.ecoLevel,
    weeklyPoints: userProfile.weeklyScore,
    totalPoints: userProfile.totalScore,
    streak: userProfile.dayStreak,
    completedChallenges: userProfile.completedChallenges?.length || 0,
    earnedBadges: userProfile.earnedBadges || [],
    joinDate: userProfile.joinedAt?.toDate ? 
      userProfile.joinedAt.toDate().toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 
      'Recently'
  } : {
    name: 'Eco Warrior',
    uniqueId: '#ECO2024',
    level: 1,
    weeklyPoints: 0,
    totalPoints: 0,
    streak: 0,
    completedChallenges: 0,
    earnedBadges: [],
    joinDate: 'Recently'
  };

  const allBadges = [
    { id: 'first_challenge', icon: Award, name: 'First Steps', description: 'Completed first challenge', color: 'text-blue-500', bgColor: 'bg-blue-100' },
    { id: 'eco_warrior', icon: TreePine, name: 'Eco Warrior', description: 'Reached 500 total points', color: 'text-emerald-500', bgColor: 'bg-emerald-100' },
    { id: 'green_champion', icon: Zap, name: 'Green Champion', description: 'Reached 1000 total points', color: 'text-yellow-500', bgColor: 'bg-yellow-100' },
    { id: 'challenge_master', icon: Sun, name: 'Challenge Master', description: 'Completed 10 challenges', color: 'text-orange-500', bgColor: 'bg-orange-100' },
    { id: 'sustainability_hero', icon: Recycle, name: 'Sustainability Hero', description: 'Reached 2000 total points', color: 'text-purple-500', bgColor: 'bg-purple-100' },
    { id: 'water_saver', icon: Droplets, name: 'Water Saver', description: 'Completed water conservation challenges', color: 'text-blue-500', bgColor: 'bg-blue-100' },
    { id: 'recycler', icon: Recycle, name: 'Recycler', description: 'Completed recycling challenges', color: 'text-green-500', bgColor: 'bg-green-100' },
    { id: 'tree_planter', icon: TreePine, name: 'Tree Planter', description: 'Planted trees or started gardens', color: 'text-green-600', bgColor: 'bg-green-100' },
    { id: 'energy_saver', icon: Zap, name: 'Energy Saver', description: 'Completed energy saving challenges', color: 'text-yellow-500', bgColor: 'bg-yellow-100' },
    { id: 'solar_advocate', icon: Sun, name: 'Solar Advocate', description: 'Promoted renewable energy', color: 'text-orange-500', bgColor: 'bg-orange-100' },
    { id: 'green_commuter', icon: Leaf, name: 'Green Commuter', description: 'Used eco-friendly transportation', color: 'text-green-500', bgColor: 'bg-green-100' }
  ];

  // Filter badges to show only earned ones
  const earnedBadges = allBadges.filter(badge => userStats.earnedBadges.includes(badge.id));

  // Generate recent achievements based on user data
  const generateRecentAchievements = () => {
    const achievements = [];
    
    if (userStats.completedChallenges > 0) {
      achievements.push({
        title: 'Challenge Completed',
        date: new Date().toLocaleDateString(),
        points: 50
      });
    }
    
    if (userStats.weeklyPoints > 0) {
      achievements.push({
        title: 'Weekly Progress',
        date: new Date().toLocaleDateString(),
        points: userStats.weeklyPoints
      });
    }
    
    if (userStats.level > 1) {
      achievements.push({
        title: `Reached Level ${userStats.level}`,
        date: new Date().toLocaleDateString(),
        points: (userStats.level - 1) * 500
      });
    }
    
    return achievements.slice(0, 4); // Show max 4 recent achievements
  };

  const handleEditProfile = () => {
    setIsEditingProfile(true);
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    
    try {
      const userRef = doc(db, 'users', user.uid);
      await updateDoc(userRef, {
        displayName: editForm.displayName
      });
      
      showToast('Profile updated successfully!', 'success');
      setIsEditingProfile(false);
    } catch (error) {
      showToast('Failed to update profile', 'error');
    }
  };

  const handleSettings = () => {
    setShowSettings(true);
  };

  const handleSaveSettings = () => {
    // Save settings to localStorage for now
    localStorage.setItem('userSettings', JSON.stringify(settingsForm));
    showToast('Settings saved successfully!', 'success');
    setShowSettings(false);
  };

  const handleShareProfile = () => {
    const shareData = {
      title: `${userStats.name}'s Eco Profile`,
      text: `Check out my eco journey! Level ${userStats.level} with ${userStats.totalPoints} total points on Carbon Crush!`,
      url: `${window.location.origin}/profile/${user?.uid || 'demo'}`
    };
    
    if (navigator.share) {
      navigator.share(shareData).then(() => {
        showToast('Profile shared successfully!', 'success');
      }).catch(() => {
        navigator.clipboard.writeText(shareData.url);
        showToast('Profile link copied to clipboard!', 'success');
      });
    } else {
      navigator.clipboard.writeText(shareData.url);
      showToast('Profile link copied to clipboard!', 'success');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-100">
      {/* Header */}
      <motion.div
        className="bg-white shadow-lg rounded-b-3xl p-6 mb-6"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <motion.button
              onClick={() => onNavigate('home')}
              className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <ArrowLeft className="w-6 h-6 text-gray-600" />
            </motion.button>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Profile</h1>
              <p className="text-gray-600">Your eco journey</p>
            </div>
          </div>
          <motion.button
            onClick={handleSettings}
            className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Settings className="w-6 h-6 text-gray-600" />
          </motion.button>
        </div>
      </motion.div>

      <div className="px-6 pb-24">
        {/* Profile Card */}
        <motion.div
          className="bg-white rounded-2xl p-6 mb-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex items-center space-x-4 mb-6">
            <div className="relative">
              <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
                {user?.photoURL ? (
                  <img src={user.photoURL} alt="Profile" className="w-18 h-18 rounded-full object-cover" />
                ) : (
                  <Leaf className="w-10 h-10 text-white" />
                )}
              </div>
              <motion.button
                onClick={handleEditProfile}
                className="absolute -bottom-1 -right-1 bg-blue-500 text-white p-2 rounded-full shadow-lg"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.9 }}
              >
                <Edit className="w-4 h-4" />
              </motion.button>
            </div>
            <div className="flex-1">
              {isEditingProfile ? (
                <input
                  type="text"
                  value={editForm.displayName}
                  onChange={(e) => setEditForm({...editForm, displayName: e.target.value})}
                  className="text-2xl font-bold text-gray-800 bg-transparent border-b-2 border-green-400 focus:outline-none"
                />
              ) : (
                <h2 className="text-2xl font-bold text-gray-800">{userStats.name}</h2>
              )}
              <p className="text-gray-600">{userStats.uniqueId}</p>
              <div className="flex items-center space-x-4 mt-2">
                <div className="flex items-center space-x-1">
                  <Award className="w-4 h-4 text-yellow-500" />
                  <span className="text-sm font-medium text-gray-700">Level {userStats.level}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Calendar className="w-4 h-4 text-blue-500" />
                  <span className="text-sm text-gray-600">Joined {userStats.joinDate}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Bio Section */}
          <div className="mb-6">
            <h3 className="font-semibold text-gray-800 mb-2">Bio</h3>
            {isEditingProfile ? (
              <textarea
                value={editForm.bio}
                onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                className="w-full text-gray-600 text-sm bg-gray-50 p-2 rounded-lg border focus:outline-none focus:ring-2 focus:ring-green-400"
                rows={3}
              />
            ) : (
              <p className="text-gray-600 text-sm">{editForm.bio}</p>
            )}
          </div>

          {/* Save/Cancel buttons for editing */}
          {isEditingProfile && (
            <div className="flex space-x-3 mb-6">
              <motion.button
                onClick={handleSaveProfile}
                className="flex-1 bg-green-500 hover:bg-green-600 text-white py-2 px-4 rounded-lg font-medium"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Save Changes
              </motion.button>
              <motion.button
                onClick={() => setIsEditingProfile(false)}
                className="flex-1 bg-gray-300 hover:bg-gray-400 text-gray-800 py-2 px-4 rounded-lg font-medium"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                Cancel
              </motion.button>
            </div>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">{userStats.weeklyPoints}</div>
              <div className="text-xs text-gray-600">Weekly Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{userStats.totalPoints.toLocaleString()}</div>
              <div className="text-xs text-gray-600">Total Points</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-purple-600">{userStats.streak}</div>
              <div className="text-xs text-gray-600">Day Streak</div>
            </div>
          </div>
        </motion.div>

        {/* EcoLevel Progress */}
        <motion.div
          className="bg-white rounded-2xl p-6 mb-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-gray-800">EcoLevel Progress</h3>
            <div className="flex items-center space-x-1 text-green-600">
              <TrendingUp className="w-4 h-4" />
              <span className="text-sm font-medium">Level {userStats.level}</span>
            </div>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-3 mb-2">
            <motion.div
              className="bg-gradient-to-r from-green-400 to-emerald-500 h-3 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: '70%' }}
              transition={{ duration: 1, delay: 0.5 }}
            />
          </div>
          <div className="flex justify-between text-sm text-gray-600">
            <span>Level {userStats.level}</span>
            <span>Level {userStats.level + 1}</span>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            {300 - (userStats.weeklyPoints % 300)} points to next level
          </p>
        </motion.div>

        {/* Badges Grid */}
        <motion.div
          className="bg-white rounded-2xl p-6 mb-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.6 }}
        >
          <h3 className="font-bold text-gray-800 mb-4">Badges Earned</h3>
          {earnedBadges.length > 0 ? (
            <div className="grid grid-cols-2 gap-4">
              {earnedBadges.map((badge, index) => (
                <motion.div
                  key={badge.id}
                  className={`${badge.bgColor} rounded-xl p-4 text-center`}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ duration: 0.4, delay: 0.1 * index }}
                  whileHover={{ scale: 1.05 }}
                >
                  <badge.icon className={`w-8 h-8 ${badge.color} mx-auto mb-2`} />
                  <div className="font-semibold text-gray-800 text-sm">{badge.name}</div>
                  <div className="text-xs text-gray-600 mt-1">{badge.description}</div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <Award className="w-12 h-12 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-600">Complete challenges to earn badges!</p>
            </div>
          )}
        </motion.div>

        {/* Recent Achievements */}
        <motion.div
          className="bg-white rounded-2xl p-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h3 className="font-bold text-gray-800 mb-4">Recent Achievements</h3>
          {generateRecentAchievements().length > 0 ? (
            <div className="space-y-3">
              {generateRecentAchievements().map((achievement, index) => (
                <motion.div
                  key={achievement.title}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-xl"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: 0.1 * index }}
                >
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-yellow-100 rounded-full flex items-center justify-center">
                      <Award className="w-5 h-5 text-yellow-600" />
                    </div>
                    <div>
                      <div className="font-semibold text-gray-800 text-sm">{achievement.title}</div>
                      <div className="text-xs text-gray-600">{achievement.date}</div>
                    </div>
                  </div>
                  <div className="text-green-600 font-bold text-sm">+{achievement.points}</div>
                </motion.div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8">
              <TrendingUp className="w-12 h-12 text-gray-300 mx-auto mb-2" />
              <p className="text-gray-600">Complete challenges to see achievements!</p>
            </div>
          )}
        </motion.div>

        {/* Share Profile Button */}
        <motion.button
          onClick={handleShareProfile}
          className="w-full mt-6 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-4 px-6 rounded-2xl font-bold shadow-lg flex items-center justify-center space-x-2"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 1 }}
        >
          <Share className="w-6 h-6" />
          <span>Share Profile</span>
        </motion.button>
      </div>

      {/* Settings Modal */}
      {showSettings && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <motion.div
            className="bg-white rounded-2xl max-w-md w-full max-h-[80vh] overflow-y-auto"
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
          >
            {/* Header */}
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-gray-800">Settings</h2>
                <button
                  onClick={() => setShowSettings(false)}
                  className="p-2 hover:bg-gray-100 rounded-full"
                >
                  <X className="w-5 h-5 text-gray-500" />
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Account Settings */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <UserIcon className="w-5 h-5 mr-2" />
                  Account
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Email</span>
                    <span className="text-gray-500 text-sm">{user?.email}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Member Since</span>
                    <span className="text-gray-500 text-sm">{userStats.joinDate}</span>
                  </div>
                </div>
              </div>

              {/* Notifications */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <Bell className="w-5 h-5 mr-2" />
                  Notifications
                </h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-gray-700">Push Notifications</span>
                    <label className="relative inline-flex items-center cursor-pointer">
                      <input
                        type="checkbox"
                        checked={settingsForm.notifications}
                        onChange={(e) => setSettingsForm({...settingsForm, notifications: e.target.checked})}
                        className="sr-only peer"
                      />
                      <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-blue-600"></div>
                    </label>
                  </div>
                </div>
              </div>

              {/* Privacy */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <Shield className="w-5 h-5 mr-2" />
                  Privacy
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-gray-700 mb-2">Profile Visibility</label>
                    <select
                      value={settingsForm.privacy}
                      onChange={(e) => setSettingsForm({...settingsForm, privacy: e.target.value})}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-400"
                    >
                      <option value="public">Public</option>
                      <option value="friends">Friends Only</option>
                      <option value="private">Private</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Theme */}
              <div>
                <h3 className="font-semibold text-gray-800 mb-3 flex items-center">
                  <Palette className="w-5 h-5 mr-2" />
                  Appearance
                </h3>
                <div className="space-y-3">
                  <div>
                    <label className="block text-gray-700 mb-2">Theme</label>
                    <select
                      value={settingsForm.theme}
                      onChange={(e) => setSettingsForm({...settingsForm, theme: e.target.value})}
                      className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-400"
                    >
                      <option value="light">Light</option>
                      <option value="dark">Dark</option>
                      <option value="auto">Auto</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Save Button */}
              <motion.div
                className="pt-4 border-t border-gray-100"
              >
                <motion.button
                  onClick={handleSaveSettings}
                  className="w-full bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 px-6 rounded-xl font-bold"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Save Settings
                </motion.button>
              </motion.div>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};

export default ProfilePage;