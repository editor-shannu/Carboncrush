import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { User } from 'firebase/auth';
import { createPost, subscribeToPosts, likePost, formatTimeAgo, Post } from '../lib/supabase';
import { 
  ArrowLeft, 
  Heart, 
  MessageCircle, 
  Share, 
  Plus,
  Camera,
  Video,
  Award,
  Leaf
} from 'lucide-react';

interface CommunityPageProps {
  onNavigate: (page: string) => void;
  user?: User;
  showToast: (message: string, type?: 'success' | 'error' | 'info') => void;
}

const CommunityPage: React.FC<CommunityPageProps> = ({ onNavigate, user, showToast }) => {
  const [likedPosts, setLikedPosts] = useState<number[]>([]);
  const [communityPosts, setCommunityPosts] = useState<Post[]>([]);
  const [postContent, setPostContent] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Real-time posts subscription using Supabase
  React.useEffect(() => {
    setIsLoading(true);
    setError(null);
    
    const unsubscribe = subscribeToPosts((posts) => {
      setCommunityPosts(posts);
      setIsLoading(false);
    });

    return () => {
      unsubscribe();
    };
  }, []);

  const handleCreatePost = async () => {
    if (!postContent.trim()) {
      showToast('Post content cannot be empty', 'error');
      return;
    }
    
    if (!user) {
      showToast('You must be logged in to create a post', 'error');
      return;
    }
    
    setIsSubmitting(true);
    setError(null);
    
    try {
      const author = user.displayName || user.email?.split('@')[0] || 'Anonymous User';
      console.log('Creating post for Firebase user:', user.uid, 'with author:', author);
      
      // Ensure user is authenticated with Firebase
      const token = await user.getIdToken();
      console.log('Firebase token obtained for post creation');
      
      await createPost(
        postContent.trim(),
        author,
        user.uid,
        selectedImage || undefined
      );
      
      // Reset form on success
      setPostContent('');
      setSelectedImage(null);
      showToast('Post created successfully!', 'success');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to create post';
      console.error('Post creation error:', err);
      setError(errorMessage);
      showToast(errorMessage, 'error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handlePhotoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        // Validate file size (max 5MB)
        if (file.size > 5 * 1024 * 1024) {
          showToast('File size must be less than 5MB', 'error');
          return;
        }
        
        // Validate file type
        if (!file.type.startsWith('image/')) {
          showToast('Please select a valid image file', 'error');
          return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
          setSelectedImage(e.target?.result as string);
          showToast('Image selected successfully!', 'success');
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleVideoUpload = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'video/*';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        // Validate file size (max 50MB for video)
        if (file.size > 50 * 1024 * 1024) {
          showToast('Video file size must be less than 50MB', 'error');
          return;
        }
        
        // Validate file type
        if (!file.type.startsWith('video/')) {
          showToast('Please select a valid video file', 'error');
          return;
        }
        
        const reader = new FileReader();
        reader.onload = (e) => {
          setSelectedImage(e.target?.result as string); // Using same state for simplicity
          showToast('Video selected successfully!', 'success');
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleComment = (postId: number) => {
    showToast('Comments feature coming soon!', 'info');
  };

  const handleShare = (postId: number) => {
    showToast('Share feature coming soon!', 'info');
  };

  const handleLike = async (postId: string, currentLikes: number) => {
    if (!user) return;
    
    try {
      await likePost(postId);
      // Update local state immediately for better UX
      setCommunityPosts(prev => 
        prev.map(post => 
          post.id === postId 
            ? { ...post, likes: currentLikes + 1 }
            : post
        )
      );
      showToast('Post liked!', 'success');
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Failed to like post';
      showToast(errorMessage, 'error');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-100">
      {/* Header */}
      <motion.div
        className="bg-white shadow-lg rounded-b-3xl p-6 mb-6"
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <motion.button
              onClick={() => onNavigate('home')}
              className="p-2 rounded-xl bg-gray-100 hover:bg-gray-200"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              <ArrowLeft className="w-6 h-6 text-gray-600" />
            </motion.button>
            <div>
              <h1 className="text-2xl font-bold text-gray-800">Community</h1>
              <p className="text-gray-600">Share your eco journey!</p>
            </div>
          </div>
          <motion.button
            onClick={handleCreatePost}
            className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-3 rounded-xl shadow-lg"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <Plus className="w-6 h-6" />
          </motion.button>
        </div>
      </motion.div>

      <div className="px-6 pb-24">
        {/* Create Post */}
        <motion.div
          className="bg-white rounded-2xl p-4 mb-6 shadow-lg"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
        >
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-emerald-500 rounded-full flex items-center justify-center">
              <Leaf className="w-5 h-5 text-white" />
            </div>
            <input
              type="text"
              value={postContent}
              onChange={(e) => setPostContent(e.target.value)}
              placeholder="Share your eco achievement..."
              className="flex-1 bg-gray-100 rounded-xl px-4 py-3 text-gray-700 placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-green-400"
            />
          </div>
          
          {/* Selected Image Preview */}
          {selectedImage && (
            <div className="mb-3 relative">
              {selectedImage.startsWith('data:video/') ? (
                <video src={selectedImage} className="w-full h-32 object-cover rounded-lg" controls />
              ) : (
                <img src={selectedImage} alt="Selected" className="w-full h-32 object-cover rounded-lg" />
              )}
              <button
                onClick={() => setSelectedImage(null)}
                className="absolute top-2 right-2 bg-red-500 text-white p-1 rounded-full hover:bg-red-600"
              >
                ✕
              </button>
            </div>
          )}
          
          <div className="flex items-center justify-between">
            <div className="flex space-x-4">
              <motion.button
                onClick={handlePhotoUpload}
                className="flex items-center space-x-2 text-gray-600 hover:text-green-600"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Camera className="w-5 h-5" />
                <span className="text-sm">Photo</span>
              </motion.button>
              <motion.button
                onClick={handleVideoUpload}
                className="flex items-center space-x-2 text-gray-600 hover:text-green-600"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                <Video className="w-5 h-5" />
                <span className="text-sm">Video</span>
              </motion.button>
            </div>
            <motion.button
              onClick={handleCreatePost}
              disabled={!postContent.trim() || isSubmitting}
              className="bg-green-500 hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed text-white px-6 py-2 rounded-xl font-medium flex items-center space-x-2"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              {isSubmitting ? (
                <>
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Posting...</span>
                </>
              ) : (
                <span>Post</span>
              )}
            </motion.button>
          </div>
        </motion.div>

        {/* Posts Feed */}
        <div className="space-y-6">
          {/* Error State */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
              <p className="text-red-800 font-medium">Error loading posts</p>
              <p className="text-red-600 text-sm">{error}</p>
            </div>
          )}
          
          {/* Loading State */}
          {isLoading && (
            <div className="text-center py-12">
              <div className="w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
              <p className="text-gray-600">Loading community posts...</p>
            </div>
          )}
          
          {/* Posts List */}
          {!isLoading && !error && communityPosts.map((post, index) => (
            <motion.div
              key={post.id}
              className="bg-white rounded-2xl shadow-lg overflow-hidden"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 * index }}
            >
              {/* Post Header */}
              <div className="p-4 flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-xl">
                    🌱
                  </div>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-bold text-gray-800">{post.author}</span>
                      <span className="bg-green-100 text-green-700 px-2 py-1 rounded-full text-xs font-medium">
                        Eco Warrior
                      </span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-500">{formatTimeAgo(post.timestamp)}</span>
                    </div>
                  </div>
                </div>
                <Award className="w-5 h-5 text-yellow-500" />
              </div>

              {/* Post Content */}
              <div className="px-4 pb-4">
                <p className="text-gray-800 mb-4">{post.content}</p>
                
                {/* Post Media */}
                {post.image_url && (
                  <div className="rounded-xl overflow-hidden mb-4">
                    <img
                      src={post.image_url}
                      alt="Post content"
                      className="w-full h-48 object-cover"
                    />
                  </div>
                )}
                
                {/* Post Actions */}
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center space-x-6">
                    <motion.button
                      onClick={() => handleLike(post.id, post.likes)}
                      className="flex items-center space-x-2 text-gray-600 hover:text-red-500"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Heart className="w-5 h-5" />
                      <span className="text-sm font-medium">
                        {post.likes}
                      </span>
                    </motion.button>
                    
                    <motion.button
                      onClick={() => handleComment(0)}
                      className="flex items-center space-x-2 text-gray-600 hover:text-blue-600"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <MessageCircle className="w-5 h-5" />
                      <span className="text-sm font-medium">0</span>
                    </motion.button>
                    
                    <motion.button
                      onClick={() => handleShare(0)}
                      className="flex items-center space-x-2 text-gray-600 hover:text-green-600"
                      whileHover={{ scale: 1.05 }}
                      whileTap={{ scale: 0.95 }}
                    >
                      <Share className="w-5 h-5" />
                      <span className="text-sm font-medium">Share</span>
                    </motion.button>
                  </div>
                  
                  <div className="flex items-center space-x-1 text-green-600">
                    <Award className="w-4 h-4" />
                    <span className="text-sm font-medium">+5 XP</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Empty State */}
        {!isLoading && !error && communityPosts.length === 0 && (
          <motion.div 
            className="text-center py-12"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1 }}
          >
            <div className="text-6xl mb-4">🌱</div>
            <h3 className="text-lg font-semibold text-gray-800 mb-2">
              No posts yet
            </h3>
            <p className="text-gray-600">
              Be the first to share your eco journey!
            </p>
          </motion.div>
        )}

        {/* Load More */}
        {!isLoading && !error && communityPosts.length > 0 && (
          <motion.button
          onClick={() => alert('Loading more posts...')}
          className="w-full mt-6 bg-gray-100 hover:bg-gray-200 text-gray-700 py-4 px-6 rounded-2xl font-medium"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          Load More Posts
        </motion.button>
        )}
      </div>
    </div>
  );
};

export default CommunityPage;