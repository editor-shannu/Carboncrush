import { 
  collection, 
  addDoc, 
  getDocs, 
  doc, 
  setDoc, 
  getDoc, 
  updateDoc, 
  increment, 
  query, 
  orderBy, 
  onSnapshot,
  serverTimestamp,
  where,
  runTransaction,
  Timestamp
} from 'firebase/firestore';
import { db } from './config';
import { User } from 'firebase/auth';

// User Profile Interface
export interface UserProfile {
  uid: string;
  displayName: string;
  email: string;
  photoURL?: string;
  ecoLevel: number;
  weeklyScore: number;
  totalScore: number;
  dayStreak: number;
  lastActiveDate: string; // ISO date string for streak tracking
  weekStartDate: string; // ISO date string for weekly reset
  onboardingCompleted: boolean;
  completedChallenges: string[];
  earnedBadges: string[];
  posts: string[];
  joinedAt: any;
  lastActive: any;
}

// Community Post Interface
export interface CommunityPost {
  id?: string;
  userId: string;
  userName: string;
  userAvatar: string;
  userLevel: number;
  content: string;
  image?: string;
  challengeCompletion?: {
    challengeId: string;
    challengeTitle: string;
    points: number;
    difficulty: string;
  };
  likes: number;
  likedBy: string[];
  comments: number;
  createdAt: any;
  badges: string[];
}

// Challenge Proof Interface
export interface ChallengeProof {
  id?: string;
  userId: string;
  challengeId: string;
  challengeTitle: string;
  difficulty: string;
  points: number;
  description: string;
  image?: string;
  completedAt: any;
  verified: boolean;
}

// Challenge completion record
export interface ChallengeCompletion {
  id?: string;
  userId: string;
  challengeId: string;
  challengeTitle: string;
  difficulty: string;
  points: number;
  completedAt: any;
  weekNumber: number;
  verified: boolean;
}

// Friend relationship
export interface FriendRelation {
  id?: string;
  userId: string;
  friendId: string;
  status: 'pending' | 'accepted' | 'blocked';
  createdAt: any;
}

// Get current week number
const getCurrentWeekNumber = (): number => {
  const now = new Date();
  const start = new Date(now.getFullYear(), 0, 1);
  const diff = now.getTime() - start.getTime();
  const oneWeek = 1000 * 60 * 60 * 24 * 7;
  return Math.ceil(diff / oneWeek);
};

// Get today's date string
const getTodayString = (): string => {
  return new Date().toISOString().split('T')[0];
};

// Calculate eco level from total points
const calculateEcoLevel = (totalPoints: number): number => {
  return Math.floor(totalPoints / 500) + 1;
};

// Check if user earned new badges
const checkForNewBadges = (userProfile: UserProfile): string[] => {
  const newBadges: string[] = [];
  const { totalScore, completedChallenges, earnedBadges } = userProfile;
  
  const badgeCriteria = [
    { id: 'first_challenge', name: 'First Steps', condition: completedChallenges.length >= 1 },
    { id: 'eco_warrior', name: 'Eco Warrior', condition: totalScore >= 500 },
    { id: 'green_champion', name: 'Green Champion', condition: totalScore >= 1000 },
    { id: 'challenge_master', name: 'Challenge Master', condition: completedChallenges.length >= 10 },
    { id: 'sustainability_hero', name: 'Sustainability Hero', condition: totalScore >= 2000 },
    // Add more specific badges based on challenge types
    { id: 'water_saver', name: 'Water Saver', condition: completedChallenges.some(id => id.includes('water')) },
    { id: 'recycler', name: 'Recycler', condition: completedChallenges.some(id => id.includes('recycle')) },
    { id: 'tree_planter', name: 'Tree Planter', condition: completedChallenges.some(id => id.includes('tree') || id.includes('plant')) },
    { id: 'energy_saver', name: 'Energy Saver', condition: completedChallenges.some(id => id.includes('energy') || id.includes('light')) },
    { id: 'solar_advocate', name: 'Solar Advocate', condition: completedChallenges.some(id => id.includes('solar') || id.includes('renewable')) },
    { id: 'green_commuter', name: 'Green Commuter', condition: completedChallenges.some(id => id.includes('transport') || id.includes('bike') || id.includes('walk')) }
  ];
  
  badgeCriteria.forEach(badge => {
    if (badge.condition && !earnedBadges.includes(badge.id)) {
      newBadges.push(badge.id);
    }
  });
  
  return newBadges;
};

// Initialize new user profile
export const initializeUserProfile = async (user: User): Promise<void> => {
  try {
    const userRef = doc(db, 'users', user.uid);
    const userSnap = await getDoc(userRef);
    
    // Only initialize if user doesn't exist
    if (!userSnap.exists()) {
      const today = getTodayString();
      
      const newUserProfile: UserProfile = {
        uid: user.uid,
        displayName: user.displayName || user.email?.split('@')[0] || 'Anonymous User',
        email: user.email || '',
        photoURL: user.photoURL || '',
        ecoLevel: 1,      // Start at level 1
        weeklyScore: 100, // 100 points bonus for new users
        totalScore: 100,  // 100 points bonus for new users
        dayStreak: 0,     // Start with 0 streak
        lastActiveDate: today,
        weekStartDate: today,
        onboardingCompleted: true,
        completedChallenges: [], // Start with no completed challenges
        earnedBadges: [],        // Start with no badges - earn through challenges
        posts: [],
        joinedAt: serverTimestamp(),
        lastActive: serverTimestamp()
      };
      
      await setDoc(userRef, newUserProfile);
      console.log('New user profile created: Level 1, 100 bonus points, 0 badges');
    } else {
      // Update activity and check for streak
      const userData = userSnap.data() as UserProfile;
      const today = getTodayString();
      const lastActiveDate = userData.lastActiveDate || today;
      
      let newStreak = userData.dayStreak || 0;
      
      if (lastActiveDate !== today) {
        const lastDate = new Date(lastActiveDate);
        const todayDate = new Date(today);
        const daysDiff = Math.floor((todayDate.getTime() - lastDate.getTime()) / (1000 * 60 * 60 * 24));
        
        if (daysDiff === 1) {
          // Consecutive day
          newStreak += 1;
        } else if (daysDiff > 1) {
          // Streak broken
          newStreak = 0; // Reset to 0, not 1
        }
        // If daysDiff === 0, same day, no change to streak
        
        await updateDoc(userRef, {
          lastActive: serverTimestamp(),
          lastActiveDate: today,
          dayStreak: newStreak
        });
      } else {
        // Same day, just update last active
        await updateDoc(userRef, {
          lastActive: serverTimestamp()
        });
      }
    }
  } catch (error) {
    console.error('Error initializing user profile:', error);
    throw error;
  }
};

// Get user profile
export const getUserProfile = async (userId: string): Promise<UserProfile | null> => {
  try {
    const userRef = doc(db, 'users', userId);
    const userSnap = await getDoc(userRef);
    
    if (userSnap.exists()) {
      return { id: userSnap.id, ...userSnap.data() } as UserProfile;
    }
    return null;
  } catch (error) {
    console.error('Error getting user profile:', error);
    throw error;
  }
};

// Create community post
export const createCommunityPost = async (
  user: User, 
  content: string, 
  image?: string,
  challengeCompletion?: {
    challengeId: string;
    challengeTitle: string;
    points: number;
    difficulty: string;
  }
): Promise<string> => {
  try {
    console.log('Creating community post for user:', user.uid);
    
    // Get user profile for current level
    const userProfile = await getUserProfile(user.uid);
    console.log('User profile retrieved:', userProfile?.displayName);
    
    const postData: Omit<CommunityPost, 'id'> = {
      userId: user.uid,
      userName: user.displayName || user.email?.split('@')[0] || 'Anonymous User',
      userAvatar: user.photoURL || '🌱',
      userLevel: userProfile?.ecoLevel || 0,
      content,
      image,
      challengeCompletion,
      likes: 0,
      likedBy: [],
      comments: 0,
      createdAt: serverTimestamp(),
      badges: challengeCompletion ? ['♻️', '💧'] : []
    };
    
    console.log('Post data prepared:', {
      userId: postData.userId,
      userName: postData.userName,
      content: postData.content,
      hasImage: !!postData.image
    });
    
    const docRef = await addDoc(collection(db, 'posts'), postData);
    console.log('Post created with ID:', docRef.id);
    
    // Update user's posts array
    if (userProfile) {
      await updateDoc(doc(db, 'users', user.uid), {
        posts: [...userProfile.posts, docRef.id]
      });
      console.log('User posts array updated');
    }
    
    return docRef.id;
  } catch (error) {
    console.error('Error creating community post:', error);
    // Re-throw with more specific error message
    if (error instanceof Error) {
      throw new Error(`Failed to create post: ${error.message}`);
    }
    throw error;
  }
};

// Get community posts with real-time updates
export const getCommunityPosts = (callback: (posts: CommunityPost[]) => void) => {
  const q = query(
    collection(db, 'posts'),
    orderBy('createdAt', 'desc')
  );
  
  return onSnapshot(q, (querySnapshot) => {
    const posts: CommunityPost[] = [];
    querySnapshot.forEach((doc) => {
      const postData = doc.data();
      posts.push({ 
        id: doc.id, 
        ...postData,
        // Ensure createdAt is properly handled
        createdAt: postData.createdAt || serverTimestamp()
      } as CommunityPost);
    });
    console.log('Fetched posts:', posts.length); // Debug log
    callback(posts);
  }, (error) => {
    console.error('Error fetching community posts:', error);
    // Call callback with empty array on error to prevent UI hanging
    callback([]);
  });
};

// Submit challenge proof
export const submitChallengeProof = async (
  user: User,
  challengeId: string,
  challengeTitle: string,
  difficulty: string,
  points: number,
  description: string,
  image?: string
): Promise<{ success: boolean; newUserProfile?: UserProfile }> => {
  try {
    const currentWeek = getCurrentWeekNumber();
    
    // Check if challenge already completed this week
    const completionQuery = query(
      collection(db, 'challengeCompletions'),
      where('userId', '==', user.uid),
      where('challengeId', '==', challengeId),
      where('weekNumber', '==', currentWeek)
    );
    
    const existingCompletions = await getDocs(completionQuery);
    if (!existingCompletions.empty) {
      throw new Error('Challenge already completed this week');
    }
    
    // Use transaction to ensure atomicity
    const result = await runTransaction(db, async (transaction) => {
      const userRef = doc(db, 'users', user.uid);
      const userDoc = await transaction.get(userRef);
      
      if (!userDoc.exists()) {
        throw new Error('User profile not found');
      }
      
      const userData = userDoc.data() as UserProfile;
      
      // Create challenge completion record
      const completionRef = doc(collection(db, 'challengeCompletions'));
      const completionData: Omit<ChallengeCompletion, 'id'> = {
        userId: user.uid,
        challengeId,
        challengeTitle,
        difficulty,
        points,
        completedAt: serverTimestamp(),
        weekNumber: currentWeek,
        verified: true
      };
      
      transaction.set(completionRef, completionData);
      
      // Update user profile
      const newTotalScore = userData.totalScore + points;
      const newWeeklyScore = userData.weeklyScore + points;
      const newEcoLevel = calculateEcoLevel(newTotalScore);
      const updatedCompletedChallenges = [...(userData.completedChallenges || []), challengeId];
      
      const updatedProfile = {
        ...userData,
        weeklyScore: newWeeklyScore,
        totalScore: newTotalScore,
        ecoLevel: newEcoLevel,
        completedChallenges: updatedCompletedChallenges
      };
      
      // Check for new badges
      const newBadges = checkForNewBadges(updatedProfile);
      if (newBadges.length > 0) {
        updatedProfile.earnedBadges = [...(userData.earnedBadges || []), ...newBadges];
      }
      
      transaction.update(userRef, {
        weeklyScore: newWeeklyScore,
        totalScore: newTotalScore,
        ecoLevel: newEcoLevel,
        completedChallenges: updatedCompletedChallenges,
        earnedBadges: updatedProfile.earnedBadges
      });
      
      return updatedProfile;
    });
    
    // Create community post
    const postContent = `Just completed the "${challengeTitle}" challenge! 🎉 ${description}`;
    await createCommunityPost(user, postContent, image, {
      challengeId,
      challengeTitle,
      points,
      difficulty
    });
    
    return { success: true, newUserProfile: result };
  } catch (error) {
    console.error('Error submitting challenge proof:', error);
    return { success: false };
  }
};

// Get user's completed challenges for current week
export const getUserWeeklyCompletions = async (userId: string): Promise<string[]> => {
  try {
    const currentWeek = getCurrentWeekNumber();
    const q = query(
      collection(db, 'challengeCompletions'),
      where('userId', '==', userId),
      where('weekNumber', '==', currentWeek)
    );
    
    const snapshot = await getDocs(q);
    return snapshot.docs.map(doc => doc.data().challengeId);
  } catch (error) {
    console.error('Error getting weekly completions:', error);
    return [];
  }
};

// Search users for friends
export const searchUsers = async (searchTerm: string, currentUserId: string): Promise<UserProfile[]> => {
  try {
    if (searchTerm.length < 2) return [];
    
    const usersRef = collection(db, 'users');
    const snapshot = await getDocs(usersRef);
    
    const users: UserProfile[] = [];
    snapshot.forEach(doc => {
      const userData = doc.data() as UserProfile;
      if (
        userData.uid !== currentUserId &&
        (userData.displayName.toLowerCase().includes(searchTerm.toLowerCase()) ||
         userData.email.toLowerCase().includes(searchTerm.toLowerCase()))
      ) {
        users.push(userData);
      }
    });
    
    return users.slice(0, 10); // Limit results
  } catch (error) {
    console.error('Error searching users:', error);
    return [];
  }
};

// Send friend request
export const sendFriendRequest = async (userId: string, friendId: string): Promise<void> => {
  try {
    const friendRequestData: Omit<FriendRelation, 'id'> = {
      userId: userId,
      friendId,
      status: 'pending',
      createdAt: serverTimestamp()
    };
    
    await addDoc(collection(db, 'friendRequests'), friendRequestData);
  } catch (error) {
    console.error('Error sending friend request:', error);
    throw error;
  }
};

// Get user's friends
export const getUserFriends = async (userId: string): Promise<UserProfile[]> => {
  try {
    const friendsQuery = query(
      collection(db, 'friendRequests'),
      where('status', '==', 'accepted')
    );
    
    const snapshot = await getDocs(friendsQuery);
    const friendIds: string[] = [];
    
    snapshot.forEach(doc => {
      const data = doc.data();
      if (data.userId === userId) {
        friendIds.push(data.friendId);
      } else if (data.friendId === userId) {
        friendIds.push(data.userId);
      }
    });
    
    // Get friend profiles
    const friends: UserProfile[] = [];
    for (const friendId of friendIds) {
      const friendProfile = await getUserProfile(friendId);
      if (friendProfile) {
        friends.push(friendProfile);
      }
    }
    
    return friends.sort((a, b) => b.weeklyScore - a.weeklyScore);
  } catch (error) {
    console.error('Error getting user friends:', error);
    return [];
  }
};

// Get leaderboard data with real-time updates
export const getLeaderboard = (callback: (users: UserProfile[]) => void, type: 'global' | 'friends' = 'global', userId?: string) => {
  const q = query(
    collection(db, 'users'),
    orderBy('weeklyScore', 'desc')
  );
  
  return onSnapshot(q, (querySnapshot) => {
    const users: UserProfile[] = [];
    querySnapshot.forEach((doc) => {
      users.push({ id: doc.id, ...doc.data() } as UserProfile);
    });
    
    if (type === 'friends' && userId) {
      // Filter to show only friends - for now show all users as demo
      callback(users);
    } else {
      callback(users);
    }
  }, (error) => {
    console.error('Error fetching leaderboard:', error);
  });
};

// Like/unlike post
export const togglePostLike = async (postId: string, userId: string): Promise<void> => {
  try {
    const postRef = doc(db, 'posts', postId);
    const postSnap = await getDoc(postRef);
    
    if (postSnap.exists()) {
      const postData = postSnap.data() as CommunityPost;
      const likedBy = postData.likedBy || [];
      const isLiked = likedBy.includes(userId);
      
      if (isLiked) {
        // Unlike
        await updateDoc(postRef, {
          likes: increment(-1),
          likedBy: likedBy.filter(id => id !== userId)
        });
      } else {
        // Like
        await updateDoc(postRef, {
          likes: increment(1),
          likedBy: [...likedBy, userId]
        });
      }
    }
  } catch (error) {
    console.error('Error toggling post like:', error);
    throw error;
  }
};

// Weekly reset function (can be called manually or via Cloud Function)
export const performWeeklyReset = async (): Promise<void> => {
  try {
    const currentWeek = getCurrentWeekNumber();
    const usersRef = collection(db, 'users');
    const snapshot = await getDocs(usersRef);
    
    const updates: Promise<void>[] = [];
    snapshot.forEach((doc) => {
      const userData = doc.data() as UserProfile;
      const userWeekStart = userData.weekStartDate ? new Date(userData.weekStartDate) : new Date();
      const weeksDiff = currentWeek - getCurrentWeekNumber();
      
      if (weeksDiff >= 1) {
        updates.push(updateDoc(doc.ref, { 
          weeklyScore: 0,
          weekStartDate: getTodayString()
        }));
      }
    });
    
    await Promise.all(updates);
    console.log('Weekly scores reset for all users');
  } catch (error) {
    console.error('Error resetting weekly scores:', error);
    throw error;
  }
};