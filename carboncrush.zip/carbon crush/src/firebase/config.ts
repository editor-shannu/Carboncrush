import { initializeApp } from "firebase/app";
import { getAuth, GoogleAuthProvider } from "firebase/auth";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyBtSZoIPXB08mbsQGqZmLbJdz9aqnmxaEE",
  authDomain: "carbon-crush.firebaseapp.com",
  projectId: "carbon-crush",
  storageBucket: "carbon-crush.firebasestorage.app",
  messagingSenderId: "733349547884",
  appId: "1:733349547884:web:986817e066c64fc6926d49",
  measurementId: "G-JNJE7FTD6K"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
export const db = getFirestore(app);