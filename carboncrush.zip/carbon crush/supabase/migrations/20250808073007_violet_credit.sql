/*
  # Create posts table for community feature

  1. New Tables
    - `posts`
      - `id` (uuid, primary key)
      - `author` (text, user's display name)
      - `content` (text, post content)
      - `timestamp` (timestamptz, when post was created)
      - `likes` (integer, default 0)
      - `user_id` (uuid, references auth.users)
      - `image_url` (text, optional image attachment)

  2. Security
    - Enable RLS on `posts` table
    - Add policy for authenticated users to create posts
    - Add policy for everyone to read posts
    - Add policy for users to update their own posts (for likes)
*/

CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author text NOT NULL,
  content text NOT NULL,
  timestamp timestamptz DEFAULT now(),
  likes integer DEFAULT 0,
  user_id uuid REFERENCES auth.users(id),
  image_url text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- Allow authenticated users to create posts
CREATE POLICY "Users can create posts"
  ON posts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Allow everyone to read posts
CREATE POLICY "Anyone can read posts"
  ON posts
  FOR SELECT
  TO public
  USING (true);

-- Allow users to update their own posts (for likes)
CREATE POLICY "Users can update own posts"
  ON posts
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

-- Create index for better performance
CREATE INDEX IF NOT EXISTS posts_timestamp_idx ON posts(timestamp DESC);
CREATE INDEX IF NOT EXISTS posts_user_id_idx ON posts(user_id);