/*
  # Fix RLS policies for posts table

  1. Security
    - Enable RLS on posts table
    - Allow public read access
    - Allow authenticated users to insert posts
    - Allow users to update their own posts
*/

-- Enable RLS
ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Anyone can read posts" ON posts;
DROP POLICY IF EXISTS "Users can create posts" ON posts;
DROP POLICY IF EXISTS "Users can update own posts" ON posts;
DROP POLICY IF EXISTS "allow_insert_for_authenticated" ON posts;
DROP POLICY IF EXISTS "Allow public read" ON posts;

-- Allow anyone to read posts (public feed)
CREATE POLICY "allow_public_read"
ON posts
FOR SELECT
USING (true);

-- Allow authenticated users to insert posts
CREATE POLICY "allow_authenticated_insert"
ON posts
FOR INSERT
TO authenticated
WITH CHECK (auth.uid()::text = user_id);

-- Allow users to update their own posts (for likes, etc.)
CREATE POLICY "allow_own_posts_update"
ON posts
FOR UPDATE
TO authenticated
USING (auth.uid()::text = user_id)
WITH CHECK (auth.uid()::text = user_id);

-- Allow users to delete their own posts
CREATE POLICY "allow_own_posts_delete"
ON posts
FOR DELETE
TO authenticated
USING (auth.uid()::text = user_id);